import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { setAuthToken } from '../services/auth';
import './mcLogin.css';
//import Header from '../Home/Header';
import admin from '../images/admin.jpg';
const AdminLoginForm = ({ onLoginSuccess }) => {
  const [selectedAdmin, setSelectedAdmin] = useState("mainAdmin");
  const [formData, setFormData] = useState({
    mail: '',
    password: '',
    organizationCode: '',
  });
  const [otp, setOtp] = useState('');
  const [message, setMessage] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [timeLeft, setTimeLeft] = useState(600);
  const navigate = useNavigate();

  useEffect(() => {
    let timer;
    if (otpSent && timeLeft > 0) {
      timer = setInterval(() => setTimeLeft((prev) => prev - 1), 1000);
    } else if (timeLeft === 0) {
      setOtpSent(false);
      setMessage("OTP has expired. Please request a new one.");
    }
    return () => clearInterval(timer);
  }, [otpSent, timeLeft]);

  const handleLogin = async () => {
    setIsLoading(true);
    try {
      const endpoint = selectedAdmin === "mainAdmin"
        ? "http://localhost:5000/admin/login"
        : "http://localhost:5000/college-admin/login";

      const requestData = selectedAdmin === "mainAdmin"
        ? { mail: formData.mail, password: formData.password }
        : { 
            organizationCode: formData.organizationCode, 
            organizationMail: formData.mail, 
            password: formData.password 
          };

      const response = await axios.post(endpoint, requestData);
      
      if (selectedAdmin === "collegeAdmin" && response.data.token) {
        // Handle JWT token for college admin
        setAuthToken(response.data.token);
        navigate('/college-admin-profile');
        onLoginSuccess(selectedAdmin);
      } else {
        // Handle OTP flow for main admin
        setMessage(response.data.message);
        setOtpSent(true);
        setTimeLeft(600);
      }
    } catch (error) {
      setMessage(error.response?.data?.message || "An error occurred");
    } finally {
      setIsLoading(false);
    }
  };

  const handleOtpVerification = async () => {
    setIsLoading(true);
    try {
      // Only proceed with OTP verification for main admin
      if (selectedAdmin === "mainAdmin") {
        const response = await axios.post("http://localhost:5000/admin/verify-otp", { 
          otp: otp.toString(), 
          mail: formData.mail 
        });
        
        setMessage(response.data.message);
        const token = response.data.token;
        alert(token)
        if (response.data.message === 'OTP verified successfully!') {
          localStorage.setItem('mail', formData.mail);
          localStorage.setItem('name', response.data.name);
          localStorage.setItem('token', token);
          navigate('/adminHome');
          onLoginSuccess(selectedAdmin);
        }
      }
    } catch (error) {
      setMessage(error.response?.data?.message || "OTP verification failed");
    } finally {
      setIsLoading(false);
    }
  };

  const formatTime = (seconds) => {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="mcLogin-page">
   
  <div className="mcLogin-login-page-container">
    <div className="mcLogin-picture-container">
      <img 
        src={admin}
        alt="Login Illustration" 
        className="mcLogin-picture" 
      />
    </div>
    <div className="mcLogin-login-form-container">
      <h2 className="mcLogin-login-title">Admin Login</h2>
          {message && (
            <div className="mcLogin-login-message">
              <p>{message}</p>
            </div>
          )}

          <div className="mcLogin-admin-type-selection">
            <label>
              <input
                type="radio"
                name="adminType"
                value="mainAdmin"
                checked={selectedAdmin === "mainAdmin"}
                onChange={() => setSelectedAdmin("mainAdmin")}
              />
              Main Admin
            </label>
            <label>
              <input
                type="radio"
                name="adminType"
                value="collegeAdmin"
                checked={selectedAdmin === "collegeAdmin"}
                onChange={() => setSelectedAdmin("collegeAdmin")}
              />
              College Admin
            </label>
          </div>

          <div className="mcLogin-form-field">
            <input
              id="mcLogin-mail"
              type="email"
              required
              className="mcLogin-input-field"
              placeholder="Email"
              value={formData.mail}
              onChange={(e) => setFormData({ ...formData, mail: e.target.value })}
            />
          </div>

          <div className="mcLogin-form-field">
            <input
              id="mcLogin-password"
              type="password"
              required
              className="mcLogin-input-field"
              placeholder="Password"
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
            />
          </div>

          {selectedAdmin === "collegeAdmin" && (
            <div className="mcLogin-form-field">
              <input
                id="mcLogin-organizationCode"
                type="text"
                required
                className="mcLogin-input-field"
                placeholder="Organization Code"
                value={formData.organizationCode}
                onChange={(e) => setFormData({ ...formData, organizationCode: e.target.value })}
              />
            </div>
          )}

          <button
            type="button"
            onClick={handleLogin}
            disabled={isLoading}
            className="mcLogin-send-otp-button"
          >
            {isLoading ? "Processing..." : selectedAdmin === "mainAdmin" ? "Send OTP" : "Login"}
          </button>

          {otpSent && selectedAdmin === "mainAdmin" && (
            <div className="mcLogin-otp-verification-container">
              <div className="mcLogin-form-field">
                <input
                  type="text"
                  required
                  className="mcLogin-otp-input"
                  placeholder="Enter OTP"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value)}
                  maxLength="6"
                />
              </div>
              <button
                type="button"
                onClick={handleOtpVerification}
                disabled={isLoading}
                className="mcLogin-verify-otp-button"
              >
                {isLoading ? "Verifying..." : "Login"}
              </button>
              <p className="otp-timer">OTP expires in: {formatTime(timeLeft)}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminLoginForm;