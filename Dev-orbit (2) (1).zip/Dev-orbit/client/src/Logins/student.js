import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import jwtDecode from 'jwt-decode';
import './student.css';
import student from '../images/student-login.jpg';
//import Header from '../Home/Header';
const StudentLogin = () => {
  const [formData, setFormData] = useState({ mail: '', password: '', organizationCode: '' });
  const [status, setStatus] = useState({ message: '', type: '' });
  const [isLoading, setIsLoading] = useState(false);
  const [decodedToken, setDecodedToken] = useState(null);
  const navigate = useNavigate();


  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };


  const handleLogin = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setStatus({ message: '', type: '' });


    if (!formData.mail || !formData.password || !formData.organizationCode) {
      setStatus({ message: 'All fields are required!', type: 'error' });
      setIsLoading(false);
      return;
    }


    try {
      const response = await axios.post('http://localhost:5000/student-login', {
        mail: formData.mail,
        password: formData.password,
        organizationCode: formData.organizationCode,
      });


      const token = response.data.token;
      
      const decoded = jwtDecode(token);
      setDecodedToken(decoded);
      localStorage.setItem('token', token);
      localStorage.setItem('organizationCode', formData.organizationCode);
      localStorage.setItem('mail', formData.mail);
      localStorage.setItem('userId', decoded.id);
      localStorage.setItem('rollno', decoded.rollNo);


      setStatus({ message: 'Login successful!', type: 'success' });
      navigate('/student/student-dashboard');
    } catch (error) {
      const errorMessage = error.response?.data?.error || 'An error occurred while logging in.';
      setStatus({ message: errorMessage, type: 'error' });
    } finally {
      setIsLoading(false);
    }
  };


  useEffect(() => {
    if (decodedToken) {
      console.log('User ID:', decodedToken.id);
      console.log('Organization Code:', decodedToken.organizationCode);
    }
  }, [decodedToken]);


  return (
    <div className="student-login-page">
   
      <div className="student-login-box">
        <div className="student-login-image">
          <img src={student} alt="Login Illustration" className="student-image" />
        </div>
        <div className="student-login-form-container">
          <h2 className="student-login-title">Student Login</h2>
          <form className="student-login-form" onSubmit={handleLogin}>
            <div className="student-form-group">
              <label htmlFor="organizationCode" className="student-form-label">Organization Code</label>
              <input
                id="organizationCode"
                name="organizationCode"
                type="text"
                required
                className="student-form-input"
                placeholder="Enter organization code"
                value={formData.organizationCode}
                onChange={handleInputChange}
              />
            </div>
            <div className="student-form-group">
              <label htmlFor="mail" className="student-form-label">Email</label>
              <input
                id="mail"
                name="mail"
                type="email"
                required
                className="student-form-input"
                placeholder="Enter email address"
                value={formData.mail}
                onChange={handleInputChange}
              />
            </div>


            <div className="student-form-group">
              <label htmlFor="password" className="student-form-label">Password</label>
              <input
                id="password"
                name="password"
                type="password"
                required
                className="student-form-input"
                placeholder="Enter password"
                value={formData.password}
                onChange={handleInputChange}
              />
            </div>


            <button
              type="submit"
              disabled={isLoading}
              className="student-submit-button"
            >
              {isLoading ? 'Logging in...' : 'Login'}
            </button>
          </form>


          {status.message && (
            <div
              className={`student-status-message ${status.type === 'success' ? 'student-success-message' : 'student-error-message'}`}
              aria-live="assertive"
            >
              {status.message}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};


export default StudentLogin;



