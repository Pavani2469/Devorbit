import React, { useState, useEffect } from 'react';
import Calendar from 'react-calendar';
import './Calendar.css';
import axios from 'axios';

const MyCalendar = () => {
  const [date, setDate] = useState(new Date());
  const [reminders, setReminders] = useState({});
  const [showPopup, setShowPopup] = useState(false);
  const [selectedReminder, setSelectedReminder] = useState(null);
  const [showReminderDetails, setShowReminderDetails] = useState(false);

  // Get the JWT token from wherever you store it (localStorage, context, etc.)
  const getAuthHeader = () => {
    const token = localStorage.getItem('token'); // Or however you store your token
    return {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    };
  };

  const fetchReminders = async () => {
    try {
      const { data } = await axios.get(
        'http://localhost:5000/reminder/get-reminder',
        getAuthHeader()
      );
      const remindersObj = {};
      data.forEach(reminder => {
        // Convert ISO date string to date string format for consistency
        const reminderDate = new Date(reminder.date).toDateString();
        remindersObj[reminderDate] = {
          description: reminder.description,
          meetingLink: reminder.meetingLink
        };
      });
      setReminders(remindersObj);
    } catch (error) {
      console.error('Error fetching reminders:', error);
      if (error.response?.status === 401) {
        // Handle unauthorized access (invalid/expired token)
        // You might want to redirect to login or refresh token
        console.log('Unauthorized access. Please login again.');
      }
    }
  };

  useEffect(() => {
    fetchReminders();
  }, []);

  const handleDateChange = (selectedDate) => {
    setDate(selectedDate);
    const formattedDate = selectedDate.toDateString();
    if (reminders[formattedDate]) {
      setSelectedReminder(reminders[formattedDate]);
      setShowReminderDetails(true);
    } else {
      setSelectedReminder(null);
      setShowReminderDetails(false);
    }
  };

  const togglePopup = () => {
    setShowPopup(!showPopup);
  };

  const saveReminder = async (description, meetingLink) => {
    const formattedDate = date.toDateString();
    try {
      const response = await axios.post(
        'http://localhost:5000/reminder/add-reminder',
        {
          date: formattedDate,
          description,
          meetingLink,
        },
        getAuthHeader()
      );
      
      setReminders(prev => ({
        ...prev,
        [formattedDate]: {
          description,
          meetingLink
        }
      }));
      setSelectedReminder({ description, meetingLink });
      setShowReminderDetails(true);
      setShowPopup(false);
    } catch (error) {
      console.error('Error saving reminder:', error);
      if (error.response?.status === 401) {
        console.log('Unauthorized access. Please login again.');
      }
    }
  };

  const deleteReminder = async () => {
    const formattedDate = date.toDateString();
    try {
      await axios.delete(
        `http://localhost:5000/reminder/delete-reminder/${formattedDate}`,
        getAuthHeader()
      );
      const updatedReminders = { ...reminders };
      delete updatedReminders[formattedDate];
      setReminders(updatedReminders);
      setSelectedReminder(null);
      setShowReminderDetails(false);
    } catch (error) {
      console.error('Error deleting reminder:', error);
      if (error.response?.status === 401) {
        console.log('Unauthorized access. Please login again.');
      }
    }
  };

  // Custom tile class name function
  const tileClassName = ({ date }) => {
    const formattedDate = date.toDateString();
    return reminders[formattedDate] ? 'has-reminder' : '';
  };

  const ReminderDetails = () => {
    if (!selectedReminder || !showReminderDetails) return null;

    return (
      <div className="reminder-details-popup">
        <h3>Reminder Details</h3>
        <div className="reminder-details-content">
          <p><strong>Description:</strong> {selectedReminder.description}</p>
          {selectedReminder.meetingLink && (
            <p>
              <strong>Meeting Link:</strong>{' '}
              <a 
                href={selectedReminder.meetingLink} 
                target="_blank" 
                rel="noopener noreferrer"
                className="meeting-link"
              >
                Join Meeting
              </a>
            </p>
          )}
        </div>
        <button 
          className="close-details-btn"
          onClick={() => setShowReminderDetails(false)}
        >
          Close
        </button>
      </div>
    );
  };

  return (
    <div className="calendar-container" id="adminCalendar">
      <h2 className="calendar-header">Select a Date</h2>
      <Calendar
        onChange={handleDateChange}
        value={date}
        className="reminder-calendar"
        tileClassName={tileClassName}
      />
      
      <div className="reminder-actions">
        <button 
          onClick={togglePopup}
          className="action-button primary"
        >
          {reminders[date.toDateString()] ? 'Edit Reminder' : 'Add Reminder'}
        </button>
        {reminders[date.toDateString()] && (
          <button 
            onClick={deleteReminder}
            className="action-button delete"
          >
            Delete Reminder
          </button>
        )}
      </div>

      {showReminderDetails && <ReminderDetails />}

      {showPopup && (
        <div className="modal-overlay">
          <div className="modal-content">
            <h3 className="modal-header">
              {reminders[date.toDateString()] ? 'Edit Reminder' : 'Add Reminder'}
            </h3>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                const description = e.target.description.value;
                const meetingLink = e.target.meetingLink.value;
                saveReminder(description, meetingLink);
              }}
              className="reminder-form"
            >
              <div className="form-field">
                <label className="form-label">Description:</label>
                <input
                  type="text"
                  name="description"
                  defaultValue={reminders[date.toDateString()]?.description || ''}
                  className="form-input"
                  required
                />
              </div>
              <div className="form-field">
                <label className="form-label">Meeting Link:</label>
                <input
                  type="text"
                  name="meetingLink"
                  defaultValue={reminders[date.toDateString()]?.meetingLink || ''}
                  className="form-input"
                />
              </div>
              <div className="form-actions">
                <button
                  type="submit"
                  className="form-button submit"
                >
                  Save
                </button>
                <button
                  type="button"
                  onClick={togglePopup}
                  className="form-button cancel"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default MyCalendar;