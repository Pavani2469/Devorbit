import React, { useState } from 'react';
import axios from 'axios';
import jwt_decode from 'jwt-decode';
import ManualAddStudent from './manual-addstu';
import { Modal } from 'antd';
import './add-stu.css';

function AddStudent() {
  const [file, setFile] = useState(null);
  const [studentsData, setStudentsData] = useState([]);
  const [isUploading, setIsUploading] = useState(false);
  const [responseMessage, setResponseMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [isModalVisible, setIsModalVisible] = useState(false);

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const getAuthHeader = () => {
    const token = localStorage.getItem('token');
    let organizationCode = '';
    if (token) {
      const decodedToken = jwt_decode(token);
      organizationCode = decodedToken.organizationCode;
    }

    return {
      headers: {
        Authorization: `Bearer ${token}`,
        organizationCode: organizationCode,
      },
    };
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!file) {
      setErrorMessage('Please select an Excel file.');
      return;
    }

    const formData = new FormData();
    formData.append('file', file);

    setIsUploading(true);
    setResponseMessage('');
    setErrorMessage('');

    try {
      const response = await axios.post(
        'http://localhost:5000/upload',
        formData,
        {
          ...getAuthHeader(),
          headers: {
            ...getAuthHeader().headers,
            'Content-Type': 'multipart/form-data',
          },
        }
      );

      await getStudents();
      setIsUploading(false);
      setResponseMessage(response.data.message);
    } catch (error) {
      setIsUploading(false);
      setErrorMessage(
        error.response?.data?.error || 'An error occurred during upload.'
      );
    }
  };

  const getStudents = async () => {
    try {
      const response = await axios.get(
        'http://localhost:5000/get-students',
        getAuthHeader()
      );
      setStudentsData(response.data.students);
    } catch (error) {
      console.error('Error fetching students:', error);
      setErrorMessage('Failed to fetch students.');
    }
  };

  const sendMails = async () => {
    try {
      const response = await axios.post(
        'http://localhost:5000/send-mails',
        {},
        getAuthHeader()
      );
      alert(response.data.message);
    } catch (error) {
      console.error('Error sending emails:', error);
      alert('Failed to send emails');
    }
  };

  return (
    <div className="college-add-student-container">
      <h2 className="college-add-student-title">Upload Excel File</h2>

      <form onSubmit={handleSubmit} className="college-add-student-form">
        <div className="college-add-student-input-group">
          <label className="college-add-student-label">
            Choose Excel File
            <input
              type="file"
              onChange={handleFileChange}
              accept=".xlsx, .xls"
              className="college-add-student-file-input"
            />
          </label>
        </div>

        <div className="college-add-student-button-group">
          <button
            type="submit"
            className="college-add-student-upload-btn"
            disabled={isUploading}
          >
            {isUploading ? 'Uploading...' : 'Upload File'}
          </button>

          <button
            type="button"
            onClick={sendMails}
            className="college-add-student-send-btn"
          >
            Send Mails
          </button>

          <button
            type="button"
            onClick={() => setIsModalVisible(true)}
            className="college-add-student-manual-btn"
          >
            Manually Add Student
          </button>
        </div>

        {responseMessage && (
          <div className="college-add-student-success-message">
            {responseMessage}
          </div>
        )}

        {errorMessage && (
          <div className="college-add-student-error-message">
            {errorMessage}
          </div>
        )}
      </form>

      <Modal
        title="Manually Add Student"
        visible={isModalVisible}
        onCancel={() => setIsModalVisible(false)}
        footer={null}
      >
        <ManualAddStudent />
      </Modal>
    </div>
  );
}

export default AddStudent;
