import React, { useState } from "react";
import { useLocation } from "react-router-dom"; // Import useLocation
import './Teams.css'; // Ensure the CSS file handles card styling properly

const Teams = () => {
    const location = useLocation(); // Initialize useLocation
    const queryParams = new URLSearchParams(location.search);
    const classId = queryParams.get('classId'); // Get classId from query parameters

    // Example team data based on classId
    const teamsData = {
        1: [
            { id: 1, name: "Team A1", avatar: "https://via.placeholder.com/50" },
            { id: 2, name: "Team A2", avatar: "https://via.placeholder.com/50" },
        ],
        2: [
            { id: 3, name: "Team B1", avatar: "https://via.placeholder.com/50" },
            { id: 4, name: "Team B2", avatar: "https://via.placeholder.com/50" },
        ],
        // Add more teams for other classes as needed
    };

    const teamMembers = teamsData[classId] || []; // Get teams based on classId

    // State to track the selected team
    const [selectedTeam, setSelectedTeam] = useState(null);

    const handleTeamClick = (teamId) => {
        setSelectedTeam(teamId); // Set the selected team to the clicked team
    };

    const handleAddTask = () => {
        alert("Add Team Task clicked!");
        // Further functionality can be added here
    };

    return (
        <div className="teams-container">
            <h1>Welcome to the Teams Page!</h1>
            <h2>Teams for Class ID {classId}</h2>
            <div className="team-grid">
                {teamMembers.map(member => (
                    <div
                        key={member.id}
                        className={`team-card ${selectedTeam && selectedTeam !== member.id ? 'blurred' : ''}`}
                        onClick={() => handleTeamClick(member.id)} // Handle click to open the team
                    >
                        <img src={member.avatar} alt={member.name} className="avatar"/>
                        <p className="team-name">{member.name}</p>
                    </div>
                ))}
            </div>
            <button className="add-task-button" onClick={handleAddTask}>Add Team</button>
            <button className="add-task-button" onClick={handleAddTask}>Add Team Task</button>
        </div>
    );
};

export default Teams;