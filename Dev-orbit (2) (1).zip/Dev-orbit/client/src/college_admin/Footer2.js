import React from "react";
import "./Footer2.css";
const Footer = () => {
  return (
    <div >
     <footer className="footer2">
        <p>© 2024 DevOrbit. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default Footer;
