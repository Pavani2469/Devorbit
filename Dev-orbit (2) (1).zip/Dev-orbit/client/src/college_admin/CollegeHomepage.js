import React, { useState, useEffect } from 'react';
import { Link, Outlet, useLocation } from 'react-router-dom';
import {
  FaHome,
  FaTasks,
  FaCertificate,
  FaCalendarAlt,
  FaUser,
  FaBookOpen,
  FaBell,
  FaCommentDots,
  FaUserCircle,
  FaTimes,
} from 'react-icons/fa';
import NotificationViewer from './notifications';
import '../main_admin/Home.css';
import logo from '../images/small.png';
import devLogo from '../images/Logoo.png';
import { BsWindowSidebar } from "react-icons/bs";

const CollegeHomepage = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [userInfo, setUserInfo] = useState({ name: '', organizationCode: '' });
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const location = useLocation();

  const toggleSidebar = () => setSidebarOpen(!sidebarOpen);
  const toggleDropdown = () => setDropdownOpen(!dropdownOpen);

  useEffect(() => {
    const storedName = localStorage.getItem('name') || location.state?.name || 'Admin';
    const storedOrgCode = localStorage.getItem('organizationCode') || location.state?.organizationCode || '';
    setUserInfo({ name: storedName, organizationCode: storedOrgCode });
  }, [location.state]);

  return (
   <div className="main-admin-css-page" id="college-admin-profile">
      {/* Top Navbar */}
      <header className="main-admin-css-navbar"  style={{ marginLeft: sidebarOpen ? '250px' : '65px' }}>
        <div className="main-admin-css-navbar-content">
          <div className="main-admin-css-left-nav">
            <h1 className='main-admin-css-welcome-text'>Welcome, {userInfo.name} 😀</h1>
          </div>
          <div className="main-admin-css-navbar-icons">
            <Link to="/college-admin-profile/notifications" className="main-admin-css-icon-link" title="Messages">
              <FaBell className="main-admin-css-icon" />
            </Link>
            <Link to="/college-admin-profile/messages" className="main-admin-css-icon-link" title="Messages">
              <FaCommentDots className="main-admin-css-icon" />
            </Link>
            <Link to="/college-admin-profile/collegeProfile" className="main-admin-css-icon-link" title="Profile">
              <FaUserCircle className="main-admin-css-icon" />
            </Link>
          </div>
        </div>
      </header>

      {dropdownOpen && (
        <NotificationViewer
          toggleDropdown={toggleDropdown}
          organizationCode={userInfo.organizationCode}
        />
      )}

      {/* Sidebar */}
      <div
        className={`main-admin-css-sidebar ${sidebarOpen ? 'open' : 'closed'}`}
        onMouseEnter={() => setSidebarOpen(true)}
        onMouseLeave={() => setSidebarOpen(false)}
      >
      
        <div className="main-admin-css-logo">
          {sidebarOpen ? (
            <img src={devLogo} alt="DevOrbit Logo" className="main-admin-css-sidebar-logo-open" />
          ) : (
            <img src={logo} alt="DevOrbit Logo" className="main-admin-css-sidebar-logo" />
          )}
        </div>
        <button className="main-admin-css-toggle-btn" onClick={toggleSidebar}>
          {sidebarOpen ? <FaTimes /> : <BsWindowSidebar />}
        </button>
        <nav className="main-admin-css-nav-menu">
          <ul>
            <li>
              <Link to="/college-admin-profile/dashboard" className="main-admin-css-link">
                <FaHome className="main-admin-css-icon" />
                {sidebarOpen && <span>Home</span>}
              </Link>
            </li>
            <li>
              <Link to="/college-admin-profile/TaskLists" className="main-admin-css-link">
                <FaTasks className="main-admin-css-icon" />
                {sidebarOpen && <span>Tasks</span>}
              </Link>
            </li>
            <li>
              <Link to="/college-admin-profile/classes" className="main-admin-css-link">
                <FaBookOpen className="main-admin-css-icon" />
                {sidebarOpen && <span>Classes</span>}
              </Link>
            </li>
            <li>
              <Link to="/college-admin-profile/add-student" className="main-admin-css-link">
                <FaUser className="main-admin-css-icon" />
                {sidebarOpen && <span>Add Student</span>}
              </Link>
            </li>
            <li>
              <Link to="/college-admin-profile/adminCalendar" className="main-admin-css-link">
                <FaCalendarAlt className="main-admin-css-icon" />
                {sidebarOpen && <span>Calendar</span>}
              </Link>
            </li>
            <li>
              <Link to="/college-admin-profile/certification" className="main-admin-css-link">
                <FaCertificate className="main-admin-css-icon" />
                {sidebarOpen && <span>Certifications</span>}
              </Link>
            </li>
          
          </ul>
        </nav>
      </div>

      {/* Main Content */}
      <div className="main-admin-css-content">
        <div className="main-admin-css-home">
          <div className="main-admin-css-welcome-section">
            <Outlet />
          </div>
        </div>
      </div>
    </div>
  );
};

export default CollegeHomepage;
