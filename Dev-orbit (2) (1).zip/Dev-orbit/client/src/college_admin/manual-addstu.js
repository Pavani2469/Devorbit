import React, { useState, useEffect } from 'react';
import { Form, Input, Button, message, Select, Modal } from 'antd';
import axios from 'axios';

const ManualAddStudent = () => {
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const [classes, setClasses] = useState([]);
  const [isAddClassModalVisible, setIsAddClassModalVisible] = useState(false);
  const [newClassName, setNewClassName] = useState('');

  useEffect(() => {
    const fetchClasses = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get('http://localhost:5000/classes', {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        setClasses(response.data);
      } catch (error) {
        message.error('Failed to fetch classes');
      }
    };
    fetchClasses();
  }, []);

  const handleSubmit = async (values) => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      await axios.post('http://localhost:5000/manual-add-student', values, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      message.success('Student added successfully');
      form.resetFields();
    } catch (error) {
      message.error(error.response?.data?.error || 'Failed to add student');
    } finally {
      setLoading(false);
    }
  };

  const handleAddClass = async () => {
    if (!newClassName) return;
    try {
      const token = localStorage.getItem('token');
      await axios.post('http://localhost:5000/manual-add-class', 
        { className: newClassName }, 
        { headers: { 'Authorization': `Bearer ${token}` } }
      );
      setClasses([...classes, newClassName]);
      setIsAddClassModalVisible(false);
      setNewClassName('');
      message.success('Class added successfully');
    } catch (error) {
      message.error('Failed to add class');
    }
  };

  return (
    <>
      <Form
        form={form}
        layout="vertical"
        onFinish={handleSubmit}
        style={{ maxWidth: 600, margin: '0 auto' }}
      >
        <Form.Item
          name="name"
          label="Name"
          rules={[{ required: true, message: 'Please enter student name' }]}
        >
          <Input placeholder="Enter student name" />
        </Form.Item>

        <Form.Item
          name="rollNo"
          label="Roll Number"
          rules={[{ required: true, message: 'Please enter roll number' }]}
        >
          <Input placeholder="Enter roll number" />
        </Form.Item>

        <Form.Item
          name="class"
          label="Class"
          rules={[{ required: true, message: 'Please select class' }]}
        >
          <Select 
            placeholder="Select class"
            dropdownRender={(menu) => (
              <>
                {menu}
                <Button 
                  type="link" 
                  block 
                  onClick={() => setIsAddClassModalVisible(true)}
                >
                  + Add Class
                </Button>
              </>
            )}
          >
            {classes.map(cls => (
              <Select.Option key={cls} value={cls}>
                {cls}
              </Select.Option>
            ))}
          </Select>
        </Form.Item>

        <Form.Item
          name="mail"
          label="Email"
          rules={[
            { required: true, message: 'Please enter email' },
            { type: 'email', message: 'Please enter a valid email' }
          ]}
        >
          <Input placeholder="Enter email address" />
        </Form.Item>

        <Form.Item
          name="githubId"
          label="GitHub ID"
          rules={[{ required: false }]}
        >
          <Input placeholder="Enter GitHub username (optional)" />
        </Form.Item>

        <Form.Item
          name="team"
          label="Team"
          rules={[{ required: true, message: 'Please enter team number' }]}
        >
          <Input type="number" placeholder="Enter team number" />
        </Form.Item>

        <Form.Item
          name="role"
          label="Role"
          rules={[{ required: true, message: 'Please select role' }]}
        >
          <Select placeholder="Select role">
            <Select.Option value="Team Lead">Team Lead</Select.Option>
            <Select.Option value="Team Member">Team Member</Select.Option>
          </Select>
        </Form.Item>

        <Form.Item>
          <Button 
            type="primary" 
            htmlType="submit" 
            loading={loading}
            block
          >
            Add Student
          </Button>
        </Form.Item>
      </Form>

      <Modal
        title="Add New Class"
        visible={isAddClassModalVisible}
        onOk={handleAddClass}
        onCancel={() => setIsAddClassModalVisible(false)}
      >
        <Input 
          placeholder="Enter class name" 
          value={newClassName}
          onChange={(e) => setNewClassName(e.target.value)}
        />
      </Modal>
    </>
  );
};

export default ManualAddStudent;