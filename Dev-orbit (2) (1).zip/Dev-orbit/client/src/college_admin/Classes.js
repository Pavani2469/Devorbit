import { useState, useEffect } from 'react';
import { ChevronDown, ChevronRight, Users, Briefcase, GraduationCap } from 'lucide-react';
const Classes = () => {
  const [classes, setClasses] = useState([]);
  const [expandedClass, setExpandedClass] = useState(null);
  const [expandedTeam, setExpandedTeam] = useState(null);
  const [teams, setTeams] = useState({});
  const [students, setStudents] = useState({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);


  // Get token from localStorage
  const token = localStorage.getItem('token');


  useEffect(() => {
    fetchClasses();
  }, []);


  const fetchClasses = async () => {
    try {
      const response = await fetch('http://localhost:5000/classes', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
     
      const responseData = await response.json();
     
      if (!response.ok) {
        throw new Error(responseData.error || 'Failed to fetch classes');
      }
     
      setClasses(responseData);
    } catch (error) {
      console.error('Detailed error fetching classes:', error);
      setError(error.message);
    }
  };


  const fetchTeams = async (className) => {
    if (teams[className]) return;
   
    try {
      setLoading(true);
      setError(null);
      const response = await fetch(`http://localhost:5000/${className}/teams`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
     
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
     
      const data = await response.json();
      setTeams(prev => ({ ...prev, [className]: data }));
    } catch (error) {
      console.error('Error fetching teams:', error);
      setError('Failed to fetch teams. Please try again later.');
    } finally {
      setLoading(false);
    }
  };


  const fetchStudents = async (className, teamName) => {
    const key = `${className}-${teamName}`;
    if (students[key]) return;


    try {
      setLoading(true);
      setError(null);
      const response = await fetch(`http://localhost:5000/team/${className}/${teamName}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
     
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
     
      const data = await response.json();
      setStudents(prev => ({ ...prev, [key]: data }));
    } catch (error) {
      console.error('Error fetching students:', error);
      setError('Failed to fetch students. Please try again later.');
    } finally {
      setLoading(false);
    }
  };


  const handleClassClick = async (className) => {
    if (expandedClass === className) {
      setExpandedClass(null);
      setExpandedTeam(null);
    } else {
      setExpandedClass(className);
      setExpandedTeam(null);
      await fetchTeams(className);
    }
  };


  const handleTeamClick = async (className, teamName) => {
    const key = `${className}-${teamName}`;
    if (expandedTeam === key) {
      setExpandedTeam(null);
    } else {
      setExpandedTeam(key);
      await fetchStudents(className, teamName);
    }
  };


  if (loading && classes.length === 0) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-lg">Loading...</div>
      </div>
    );
  }


  if (error) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-red-500">{error}</div>
      </div>
    );
  }


  return (
    <div className="p-6 max-w-6xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">Organization Structure</h1>
     
      {classes.length === 0 ? (
        <div className="text-center py-8 text-gray-500">No classes found</div>
      ) : (
        <div className="space-y-4">
          {classes.map((className) => (
            <div key={className} className="border rounded-lg shadow-sm">
              <button
                onClick={() => handleClassClick(className)}
                className="w-full px-4 py-3 flex items-center gap-2 bg-gray-50 hover:bg-gray-100 rounded-t-lg"
              >
                {expandedClass === className ? <ChevronDown size={20} /> : <ChevronRight size={20} />}
                <GraduationCap size={20} />
                <span className="font-medium">{className}</span>
              </button>


              {expandedClass === className && (
                <div className="p-4">
                  {loading ? (
                    <div className="text-center py-4">Loading teams...</div>
                  ) : teams[className]?.length === 0 ? (
                    <div className="text-center py-4 text-gray-500">No teams found</div>
                  ) : (
                    <div className="space-y-3">
                      {teams[className]?.map((teamName) => (
                        <div key={teamName} className="border rounded-lg">
                          <button
                            onClick={() => handleTeamClick(className, teamName)}
                            className="w-full px-4 py-2 flex items-center gap-2 bg-gray-50 hover:bg-gray-100 rounded-t-lg"
                          >
                            {expandedTeam === `${className}-${teamName}` ? (
                              <ChevronDown size={20} />
                            ) : (
                              <ChevronRight size={20} />
                            )}
                            <Briefcase size={20} />
                            <span>{teamName}</span>
                          </button>


                          {expandedTeam === `${className}-${teamName}` && (
                            <div className="p-4">
                              {loading ? (
                                <div className="text-center py-4">Loading students...</div>
                              ) : (
                                <div className="overflow-x-auto">
                                  <table className="min-w-full divide-y divide-gray-200">
                                    <thead className="bg-gray-50">
                                      <tr>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Roll No</th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">GitHub ID</th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Role</th>
                                      </tr>
                                    </thead>
                                    <tbody className="bg-white divide-y divide-gray-200">
                                      {students[`${className}-${teamName}`]?.map((student) => (
                                        <tr key={student.rollNo}>
                                          <td className="px-6 py-4 whitespace-nowrap">{student.name}</td>
                                          <td className="px-6 py-4 whitespace-nowrap">{student.rollNo}</td>
                                          <td className="px-6 py-4 whitespace-nowrap">{student.mail}</td>
                                          <td className="px-6 py-4 whitespace-nowrap">{student.githubId || '-'}</td>
                                          <td className="px-6 py-4 whitespace-nowrap">
                                            {student.role === 'Team Lead' ? (
                                              <span className="text-green-600 font-semibold">{student.role}</span>
                                            ) : (
                                              <span className="text-gray-500">{student.role}</span>
                                            )}
                                          </td>
                                        </tr>
                                      ))}
                                    </tbody>
                                  </table>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};


export default Classes;

