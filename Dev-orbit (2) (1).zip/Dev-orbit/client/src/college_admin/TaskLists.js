import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import GiveTask from './give-task';
import './TaskLists.css'
const TaskLists = () => {
  const [tasks, setTasks] = useState({
    Project: [],
    Task: []
  });
  const [errorMessage, setErrorMessage] = useState('');
  const navigate = useNavigate();

  const api = axios.create({
    baseURL: 'http://localhost:5000',
    timeout: 5000
  });

  api.interceptors.request.use(
    (config) => {
      const token = localStorage.getItem('token');
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
      return config;
    },
    (error) => Promise.reject(error)
  );

  api.interceptors.response.use(
    (response) => response,
    (error) => {
      if (error.response?.status === 401) {
        localStorage.removeItem('token');
        navigate('/login');
        return Promise.reject(new Error('Session expired. Please login again.'));
      }
      return Promise.reject(error);
    }
  );

  useEffect(() => {
    const fetchTasks = async () => {
      try {
        const projectResponse = await api.get('/tasks/projects');
        const taskResponse = await api.get('/tasks/tasks');

        setTasks({
          Project: projectResponse.data,
          Task: taskResponse.data
        });
      } catch (error) {
        console.error('Error fetching tasks:', error);
        setErrorMessage(error.response?.data?.message || 'Failed to fetch tasks.');
      }
    };

    fetchTasks();
  }, []);

  return (
    <div className="task-page">
      <GiveTask />
      <div className="task-container">
        <h1 className="task-header">All Tasks</h1>
        {errorMessage && <div className="error-message">{errorMessage}</div>}

        <div className="task-grid">
          {['Project', 'Task'].map((type) => (
            <div key={type} className="task-section">
              <h2 className="task-type">{type}s</h2>
              {tasks[type].length === 0 ? (
                <p className="empty-message">No {type.toLowerCase()}s found</p>
              ) : (
                <ul className="task-list">
                  {tasks[type].map((task) => (
                    <li key={task._id} className="task-item">
                      <h3 className="task-title">{task.title}</h3>
                      <p className="task-description">{task.description}</p>
                      <div className="task-meta">
                        <span>
                          Start Date: {new Date(task.startDate).toLocaleDateString()} - Start Time: {new Date(task.startDate).toLocaleTimeString()}
                        </span>
                        <span>
                          End Date: {new Date(task.endDate).toLocaleDateString()} - End Time: {new Date(task.endDate).toLocaleTimeString()}
                        </span>
                        {task.filePath && (
                          <a href={`http://localhost:5000/${task.filePath}`} target="_blank" rel="noopener noreferrer">
                            View File
                          </a>
                        )}
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TaskLists;