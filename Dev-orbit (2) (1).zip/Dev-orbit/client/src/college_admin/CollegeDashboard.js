import { useEffect, useState } from "react";
import "./CollegeDashboard.css";

const Dashboard = () => {
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchDashboardData = async () => {
            const organizationCode = localStorage.getItem("organizationCode"); // Retrieve from localStorage

            if (!organizationCode) {
                setError("Organization code not found. Please log in.");
                setLoading(false);
                return;
            }

            try {
                const response = await fetch(`http://localhost:5000/college/college-dashboard/${organizationCode}`);
                if (!response.ok) {
                    throw new Error("Failed to fetch dashboard data");
                }
                const result = await response.json();
                setData(result);
            } catch (error) {
                console.error("Error fetching dashboard data:", error);
                setError("Failed to load data. Please try again.");
            } finally {
                setLoading(false);
            }
        };

        fetchDashboardData();
    }, []);

    if (loading) return <p>Loading...</p>;
    if (error) return <p className="text-red-500">{error}</p>;

    return (
        <div className="dashboard-container">
            <h2 className="dashboard-title">College Dashboard</h2>
    
            <div className="stat-grid">
                <div className="stat-card stat-blue">
                    <p>Total Students</p>
                    <p className="stat-number">{data?.studentCount}</p>
                </div>
                <div className="stat-card stat-green">
                    <p>Total Projects</p>
                    <p className="stat-number">{data?.totalProjects}</p>
                </div>
                <div className="stat-card stat-yellow">
                    <p>Total Tasks</p>
                    <p className="stat-number">{data?.totalTasks}</p>
                </div>
                <div className="stat-card stat-purple">
                    <p>Total Quizzes</p>
                    <p className="stat-number">{data?.totalQuizzes}</p>
                </div>
            </div>
        </div>
    );
    
};

export default Dashboard;
