// Certificate.js
import React from "react";
import html2canvas from 'html2canvas';
import "./Certification.css";

const Certificate = () => {
  const handleDownload = () => {
    const certificateElement = document.querySelector(".certificate-overlay");
    
    html2canvas(certificateElement, {
      scale: 2, // Higher quality
      useCORS: true, // If your background image is from a different domain
      backgroundColor: null
    }).then((canvas) => {
      const image = canvas.toDataURL("image/jpg", 1.0);
      const link = document.createElement('a');
      link.download = '../images/certificate.jpg';
      link.href = image;
      link.click();
    });
  };

  return (
    <div className="certificate-container" id="certification">
      <div className="certificate-overlay">
        {/* Certificate Title */}
        <div className="certificate-header">
          <h1>CERTIFICATE</h1>
          <h2>OF APPRECIATION</h2>
        </div>

        {/* Recipient Section */}
        <div className="certificate-body">
          <p className="presented-text">This Certificate Is Proudly Presented To</p>
          <h3 className="recipient-name">YANIS PETROS</h3>
          
          <p className="certificate-text">
            This certificate of appreciation is a reflection of your exceptional
            service and outstanding contributions. Your efforts have made a
            significant and positive impact.
          </p>
        </div>

        {/* Signature Lines */}
        <div className="signature-section">
          <div className="signature-lines">
            <div className="line">
              <span>Aaron Loeb</span>
              <span>Cahaya Dewi</span>
            </div>
            <div className="line titles">
              <span>Vice President</span>
              <span>General Manager</span>
            </div>
          </div>
        </div>
      </div>
      
      {/* Download Button */}
      <div className="download-button-container">
        <button onClick={handleDownload} className="download-button">
          Generate & Download Certificate
        </button>
      </div>
    </div>
  );
};

export default Certificate;