import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Loader2 } from "lucide-react";
import axios from 'axios';

const ProfileImage = ({ src, alt, className }) => {
  const [error, setError] = useState(false);
  const handleError = () => {
    setError(true);
  };
  
  return (
    <img 
      src={!error ? `http://localhost:5000/${src}` : "https://via.placeholder.com/150"} 
      alt={alt} 
      className={className} 
      onError={handleError} 
    />
  );
};

const CollegeAdminProfile = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [adminData, setAdminData] = useState({
    organizationName: "",
    organizationCode: "",
    organizationMail: "",
    websiteHandlerName: "",
    websiteHandlerMail: "",
    websiteHandlerPhoneNumber: "",
    profilePicture: "", // Ensure this is initialized
    registeredDate: "",
  });
  
  const [formData, setFormData] = useState({
    websiteHandlerName: "",
    websiteHandlerMail: "",
    websiteHandlerPhoneNumber: "",
    password: "",
    profilePicture: null,
  });
  
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchAdminData = async () => {
      const token = localStorage.getItem("token");
      if (!token) {
        navigate("/login");
        return;
      }
      
      try {
        const response = await fetch("http://localhost:5000/college-admin/profile", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        const profileData = data.profile;

        // Set admin data including profile picture
        setAdminData({
          organizationName: profileData.organizationName || "",
          organizationCode: profileData.organizationCode || "",
          organizationMail: profileData.organizationMail || "",
          websiteHandlerName: profileData.websiteHandlerName || "",
          websiteHandlerMail: profileData.websiteHandlerMail || "",
          websiteHandlerPhoneNumber: profileData.websiteHandlerPhoneNumber || "",
          profilePicture: profileData.profilePicture || "", // Ensure this is handled
          registeredDate: profileData.createdAt ? new Date(profileData.createdAt).toLocaleDateString() : "",
        });

        setFormData({
          websiteHandlerName: profileData.websiteHandlerName || "",
          websiteHandlerMail: profileData.websiteHandlerMail || "",
          websiteHandlerPhoneNumber: profileData.websiteHandlerPhoneNumber || "",
          password: "",
          profilePicture: null,
        });
      } catch (error) {
        setError("Error loading profile: " + (error.response?.data?.message || error.message));
      } finally {
        setLoading(false);
      }
    };

    fetchAdminData();
  }, [navigate]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e) => {
    if (e.target.files[0]) {
      setFormData((prev) => ({ ...prev, profilePicture: e.target.files[0] }));
    }
  };

  const handleProfilePictureUpload = async (file) => {
    const formData = new FormData();
    formData.append('profilePicture', file);

    try {
      const response = await axios.post(
        'http://localhost:5000/college-admin/upload-profile-picture',
        formData,
        { headers: { 'Content-Type': 'multipart/form-data', Authorization: `Bearer ${localStorage.getItem("token")}` } }
      );
      return response.data.profilePicture;
    } catch (error) {
      throw new Error('Error uploading profile picture: ' + (error.response?.data?.message || error.message));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    
    const token = localStorage.getItem("token");
    
    try {
      // Update profile details
      await axios.put(
        "http://localhost:5000/college-admin/edit-profile",
        { 
          websiteHandlerName: formData.websiteHandlerName,
          websiteHandlerMail: formData.websiteHandlerMail,
          websiteHandlerPhoneNumber: formData.websiteHandlerPhoneNumber,
          password: formData.password || undefined,
        },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      // Handle profile picture upload if needed
      if (formData.profilePicture) {
        const newProfilePicture = await handleProfilePictureUpload(formData.profilePicture);
        setAdminData(prev => ({ ...prev, profilePicture: newProfilePicture }));
      }

      alert("Profile updated successfully!");

      // Refresh profile data
      const updatedProfile = await axios.get("http://localhost:5000/college-admin/profile", { headers: { Authorization: `Bearer ${token}` } });
      
      setAdminData(prev => ({ ...prev, ...updatedProfile.data.profile }));
      
    } catch (error) {
      setError("Error updating profile: " + (error.response?.data?.message || error.message));
      
    } finally {
      setSaving(false);
      
      // Reset file input
      setFormData(prev => ({ ...prev, profilePicture: null }));
      
      const fileInput = document.getElementById('profilePicture');
      if (fileInput) {
        fileInput.value = '';
      }
    }
  };

  if (loading) {
    return (
      <div className="profile-container" id="collegeProfile">
        <div className="text-center p-6">
          <Loader2 className="animate-spin mx-auto w-8 h-8" />
          <p>Loading profile...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="profile-container" id="collegeProfile">
      <div className="profile-header">
        <ProfileImage 
          src={adminData.profilePicture ? `uploads/collegeadmin-profile-pictures/${adminData.profilePicture}` : ""} 
          alt="Profile" 
          className="profile-picture" 
        />
        <h2 className="text-xl font-bold">{adminData.organizationName}</h2>
        
        <div className="mt-4 space-y-2">
          <p><strong>Organization Code:</strong> {adminData.organizationCode}</p>
          <p><strong>Organization Email:</strong> {adminData.organizationMail}</p>
          <p><strong>Handler Name:</strong> {adminData.websiteHandlerName}</p>
          <p><strong>Handler Email:</strong> {adminData.websiteHandlerMail}</p>
          <p><strong>Handler Phone:</strong> {adminData.websiteHandlerPhoneNumber}</p>
          <p><strong>Registered on:</strong> {adminData.registeredDate}</p>
        </div>
      </div>

      <div className="profile-details">
        <h2 className="text-xl font-bold mb-4">Update Profile</h2>
        
        {error && <div className="error-message">{error}</div>}
        
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Form fields remain the same */}
          
          <div className="form-group">
            <label htmlFor="websiteHandlerName">Handler Name</label>
            <input 
              type="text" 
              id="websiteHandlerName" 
              name="websiteHandlerName" 
              value={formData.websiteHandlerName} 
              onChange={handleInputChange} 
              className="form-input" 
              placeholder="Website Handler Name" 
              required 
              disabled={saving} 
            />
          </div>

          <div className="form-group">
            <label htmlFor="websiteHandlerMail">Handler Email</label>
            <input 
              type="email" 
              id="websiteHandlerMail" 
              name="websiteHandlerMail" 
              value={formData.websiteHandlerMail} 
              onChange={handleInputChange} 
              className="form-input" 
              placeholder="Handler Email" 
              required 
              disabled={saving} 
            />
          </div>

          <div className="form-group">
            <label htmlFor="websiteHandlerPhoneNumber">Handler Phone</label>
            <input 
              type="text" 
              id="websiteHandlerPhoneNumber" 
              name="websiteHandlerPhoneNumber" 
              value={formData.websiteHandlerPhoneNumber} 
              onChange={handleInputChange} 
              className="form-input" 
              placeholder="Handler Phone Number" 
              required 
              disabled={saving} 
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">New Password (Optional)</label>
            <input 
              type="password" 
              id="password" 
              name="password" 
              value={formData.password} 
              onChange={handleInputChange} 
              className="form-input" 
              placeholder="Leave blank to keep current password" 
              disabled={saving} 
            />
          </div>

          <div className="form-group">
            <label htmlFor="profilePicture">Profile Picture</label>
            <input 
              type="file" 
              id="profilePicture" 
              name="profilePicture" 
              onChange={handleFileChange} 
              className="form-input" 
              accept="image/*" 
              disabled={saving} 
            />
          </div>

          <button type="submit" className="update-button w-full" disabled={saving}>
            {saving ? (
                <span className="flex items-center justify-center">
                  <Loader2 className="animate-spin mr-2" size={20} /> Saving...
                </span>
            ) : (
                "Save Changes"
            )}
          </button>
          
        </form>
      </div>
    </div>
  );
};

export default CollegeAdminProfile;
