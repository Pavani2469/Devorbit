import React, { useEffect, useState } from 'react';
import jwtDecode from 'jwt-decode'; // Correct import for version 4.x
import './notifications.css';

const NotificationViewer = ({ toggleDropdown }) => {
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [showNotificationForm, setShowNotificationForm] = useState(false);
  const [notificationData, setNotificationData] = useState({ title: '', message: '' });
  const [isVisible, setIsVisible] = useState(true);
  const [error, setError] = useState(null);

  const fetchNotifications = async (organizationCode) => {
    try {
      const response = await fetch(`http://localhost:5000/admin/notifications/${organizationCode}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      if (data && data.notifications && Array.isArray(data.notifications)) {
        setNotifications(data.notifications);
        setUnreadCount(data.notifications.filter((n) => n.status === 'unread').length);
      } else {
        console.warn('Invalid data structure:', data);
        setNotifications([]);
      }
      setError(null);
    } catch (error) {
      console.error('Error fetching notifications:', error);
      setError('Failed to fetch notifications');
      setNotifications([]);
    }
  };

  const getOrganizationCodeFromToken = () => {
    const token = localStorage.getItem('token');
    if (token) {
      try {
        const decodedToken = jwtDecode(token); // Decode the token
        return decodedToken.organizationCode; // Adjust according to your token structure
      } catch (error) {
        console.error('Error decoding token:', error);
        return null;
      }
    }
    return null;
  };

  useEffect(() => {
    const organizationCode = getOrganizationCodeFromToken();
    if (organizationCode && isVisible) {
      fetchNotifications(organizationCode);
    }
  }, [isVisible]);

  const handleSendNotification = async (e) => {
    e.preventDefault();
    try {
      const organizationCode = getOrganizationCodeFromToken();

      const response = await fetch('http://localhost:5000/college-admin/notifications/send-notification', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
        body: JSON.stringify({
          ...notificationData,
          organizationCode,
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      alert('Notification sent successfully!');
      setNotificationData({ title: '', message: '' });
      setShowNotificationForm(false);
      fetchNotifications(organizationCode); // Refresh notifications after sending
    } catch (error) {
      console.error('Error sending notification:', error);
      alert('Failed to send notification');
    }
  };

  return (
    <div className="college-admin-notification-container">
      {error && <div className="college-admin-notification-error">Error: {error}</div>}

      <button 
        className="college-admin-notification-button"
        onClick={() => setShowNotificationForm(!showNotificationForm)}
      >
        {showNotificationForm ? 'Cancel' : 'Send Notification'}
      </button>

      {showNotificationForm && (
        <form className="college-admin-notification-form" onSubmit={handleSendNotification}>
          <input
            className="college-admin-notification-input"
            type="text"
            placeholder="Title"
            value={notificationData.title}
            onChange={(e) => setNotificationData({ ...notificationData, title: e.target.value })}
          />
          <textarea
            className="college-admin-notification-textarea"
            placeholder="Message"
            value={notificationData.message}
            onChange={(e) => setNotificationData({ ...notificationData, message: e.target.value })}
          />
          <button 
            type="submit"
            className="college-admin-notification-submit"
          >
            Send
          </button>
        </form>
      )}

      <ul className="college-admin-notification-list">
        {notifications.map((notif) => (
          <li key={notif._id} className="college-admin-notification-item">
            <h4 className="college-admin-notification-title">{notif.title}</h4>
            <p className="college-admin-notification-message">
              {notif.message || notif.description}
            </p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default NotificationViewer;
