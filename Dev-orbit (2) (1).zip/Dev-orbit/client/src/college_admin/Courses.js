import React, { useState } from "react";
import './Courses.css'; // Import the CSS file

const Courses = () => {
    const [courses, setCourses] = useState([
        { id: 1, title: "Introduction to Programming", description: "Learn the basics of programming using Python.", duration: "4 weeks" },
        { id: 2, title: "Web Development Bootcamp", description: "Become a full-stack web developer with this comprehensive course.", duration: "12 weeks" },
        { id: 3, title: "Data Science Essentials", description: "Understand the fundamentals of data science and machine learning.", duration: "8 weeks" },
    ]);

    const [newCourse, setNewCourse] = useState({
        title: "",
        description: "",
        duration: ""
    });

    const handleGetStarted = (courseTitle) => {
        alert(`Getting started with ${courseTitle}!`); // Placeholder for actual course start logic
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setNewCourse(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    const handleAddCourse = (e) => {
        e.preventDefault();
        if (newCourse.title && newCourse.description && newCourse.duration) {
            const newCourseData = {
                id: courses.length + 1,
                title: newCourse.title,
                description: newCourse.description,
                duration: newCourse.duration
            };
            setCourses(prevCourses => [...prevCourses, newCourseData]);
            setNewCourse({ title: "", description: "", duration: "" }); // Reset form
            alert("New course added!");
        } else {
            alert("Please fill in all fields.");
        }
    };

    return (
        <div className="courses-container">
            <h1>Available Courses</h1>
            <div className="course-grid">
                {courses.map(course => (
                    <div key={course.id} className="course-card">
                        <h2>{course.title}</h2>
                        <p>{course.description}</p>
                        <p>Duration: {course.duration}</p>
                        <button 
                            className="get-started-button" 
                            onClick={() => handleGetStarted(course.title)}
                        >
                            Get Started
                        </button>
                    </div>
                ))}
            </div>

            <h2>Add New Course</h2>
            <form onSubmit={handleAddCourse} className="add-course-form">
                <input
                    type="text"
                    name="title"
                    placeholder="Course Title"
                    value={newCourse.title}
                    onChange={handleInputChange}
                    required
                />
                <input
                    type="text"
                    name="description"
                    placeholder="Course Description"
                    value={newCourse.description}
                    onChange={handleInputChange}
                    required
                />
                <input
                    type="text"
                    name="duration"
                    placeholder="Duration (e.g., 4 weeks)"
                    value={newCourse.duration}
                    onChange={handleInputChange}
                    required
                />
                <button type="submit" className="add-course-button">Add Course</button>
            </form>
        </div>
    );
};

export default Courses;
