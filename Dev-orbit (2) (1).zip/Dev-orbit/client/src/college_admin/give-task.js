import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './give-task.css';
const GiveTask = () => {
  const initialQuestionState = {
    question: '',
    options: [''],
    correctAnswer: ''
  };

  const [formData, setFormData] = useState({
    type: 'Project', // Changed from 'category' to 'type' to match backend
    title: '',
    startDate: '',
    endDate: '',
    startTime: '',
    endTime: '',
    description: '',
    file: null,
    questions: [initialQuestionState]
  });
  
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();

  const api = axios.create({
    baseURL: 'http://localhost:5000',
    timeout: 5000
  });

  api.interceptors.request.use(
    (config) => {
      const token = localStorage.getItem('token');
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
      return config;
    },
    (error) => Promise.reject(error)
  );

  api.interceptors.response.use(
    (response) => response,
    (error) => {
      if (error.response?.status === 401) {
        localStorage.removeItem('token');
        navigate('/login');
        return Promise.reject(new Error('Session expired. Please login again.'));
      }
      return Promise.reject(error);
    }
  );

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      navigate('/login');
    }
  }, [navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrorMessage('');
    setSuccessMessage('');

    const data = new FormData();
    for (const key in formData) {
      if (key === 'questions' && formData.type === 'Quiz') {
        data.append('questions', JSON.stringify(formData.questions));
      } else if (key === 'file' && formData[key]) {
        data.append('file', formData[key]);
      } else if (key !== 'file') {
        data.append(key, formData[key]);
      }
    }

    try {
      await api.post('/tasks/add-item', data, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      setSuccessMessage('Task submitted successfully!');
      setFormData({
        type: 'Project',
        title: '',
        startDate: '',
        endDate: '',
        startTime: '',
        endTime: '',
        description: '',
        file: null,
        questions: [initialQuestionState]
      });
    } catch (error) {
      console.error('Error submitting task:', error);
      setErrorMessage(error.response?.data?.message || 'Error submitting task. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  const handleFileChange = (e) => {
    setFormData((prev) => ({
      ...prev,
      file: e.target.files[0]
    }));
  };

  const handleQuestionChange = (index, field, value) => {
    const updatedQuestions = [...formData.questions];
    if (field === 'options') {
      updatedQuestions[index].options = value;
    } else {
      updatedQuestions[index][field] = value;
    }
    setFormData((prev) => ({
      ...prev,
      questions: updatedQuestions
    }));
  };

  const addQuestion = () => {
    setFormData((prev) => ({
      ...prev,
      questions: [...prev.questions, { ...initialQuestionState }]
    }));
  };

  const addOption = (questionIndex) => {
    const updatedQuestions = [...formData.questions];
    updatedQuestions[questionIndex].options.push('');
    setFormData((prev) => ({
      ...prev,
      questions: updatedQuestions
    }));
  };

  const removeOption = (questionIndex, optionIndex) => {
    const updatedQuestions = [...formData.questions];
    updatedQuestions[questionIndex].options.splice(optionIndex, 1);
    setFormData((prev) => ({
      ...prev,
      questions: updatedQuestions
    }));
  };

  const removeQuestion = (index) => {
    const updatedQuestions = [...formData.questions];
    updatedQuestions.splice(index, 1);
    setFormData((prev) => ({
      ...prev,
      questions: updatedQuestions
    }));
  };

  const handleOptionChange = (questionIndex, optionIndex, value) => {
    const updatedQuestions = [...formData.questions];
    updatedQuestions[questionIndex].options[optionIndex] = value;
    setFormData((prev) => ({
      ...prev,
      questions: updatedQuestions
    }));
  };

  const renderQuizForm = () => (
    <div className="college-give-task-quiz-container">
      {formData.questions.map((q, qIndex) => (
        <div key={qIndex} className="college-give-task-question-card">
          <button
            type="button"
            onClick={() => removeQuestion(qIndex)}
            className="college-give-task-remove-question-btn"
          >
            ×
          </button>

          <label className="college-give-task-form-label">
            <span>Question {qIndex + 1}:</span>
            <input
              type="text"
              value={q.question}
              onChange={(e) => handleQuestionChange(qIndex, 'question', e.target.value)}
              className="college-give-task-form-input"
            />
          </label>

          {q.options.map((option, oIndex) => (
            <div key={oIndex} className="college-give-task-option-container">
              <input
                type="text"
                value={option}
                onChange={(e) => handleOptionChange(qIndex, oIndex, e.target.value)}
                className="college-give-task-form-input"
                placeholder={`Option ${oIndex + 1}`}
              />
              <button
                type="button"
                onClick={() => removeOption(qIndex, oIndex)}
                className="college-give-task-remove-option-btn"
              >
                Remove
              </button>
            </div>
          ))}

          <button
            type="button"
            onClick={() => addOption(qIndex)}
            className="college-give-task-add-option-btn"
          >
            Add Option
          </button>

          <label className="college-give-task-form-label college-give-task-correct-answer">
            <span>Correct Answer:</span>
            <select
              value={q.correctAnswer}
              onChange={(e) => handleQuestionChange(qIndex, 'correctAnswer', e.target.value)}
              className="college-give-task-form-select"
            >
              <option value="">Select correct answer</option>
              {q.options.map((option, oIndex) => (
                <option key={oIndex} value={option}>
                  {option}
                </option>
              ))}
            </select>
          </label>
        </div>
      ))}
      <button
        type="button"
        onClick={addQuestion}
        className="college-give-task-add-question-btn"
      >
        Add Question
      </button>
    </div>
  );

  return (
    <div className="college-give-task-container">
      <h1 className="college-give-task-page-title">Add New Task</h1>

      <form onSubmit={handleSubmit} className="college-give-task-form">
        <div className="college-give-task-form-card">
          <label className="college-give-task-form-label">
            <span>Type:</span>
            <select
              name="type"
              value={formData.type}
              onChange={handleChange}
              className="college-give-task-form-select"
            >
              <option value="Project">Project</option>
              <option value="Task">Task</option>
              <option value="Quiz">Quiz</option>
            </select>
          </label>

          <label className="college-give-task-form-label">
            <span>Title:</span>
            <input
              type="text"
              name="title"
              value={formData.title}
              onChange={handleChange}
              required
              className="college-give-task-form-input"
            />
          </label>

          <div className="college-give-task-date-time-grid">
            <div>
              <label className="college-give-task-form-label">
                <span>Start Date:</span>
                <input
                  type="date"
                  name="startDate"
                  value={formData.startDate}
                  onChange={handleChange}
                  className="college-give-task-form-input"
                />
              </label>
            </div>
            <div>
              <label className="college-give-task-form-label">
                <span>End Date:</span>
                <input
                  type="date"
                  name="endDate"
                  value={formData.endDate}
                  onChange={handleChange}
                  className="college-give-task-form-input"
                />
              </label>
            </div>
          </div>

          <div className="college-give-task-date-time-grid">
            <div>
              <label className="college-give-task-form-label">
                <span>Start Time:</span>
                <input
                  type="time"
                  name="startTime"
                  value={formData.startTime}
                  onChange={handleChange}
                  className="college-give-task-form-input"
                />
              </label>
            </div>
            <div>
              <label className="college-give-task-form-label">
                <span>End Time:</span>
                <input
                  type="time"
                  name="endTime"
                  value={formData.endTime}
                  onChange={handleChange}
                  className="college-give-task-form-input"
                />
              </label>
            </div>
          </div>

          <label className="college-give-task-form-label">
            <span>Description:</span>
            <textarea
              name="description"
              value={formData.description}
              onChange={handleChange}
              className="college-give-task-form-textarea"
              rows="4"
            />
          </label>

          <label className="college-give-task-form-label">
            <span>Upload File:</span>
            <input
              type="file"
              onChange={handleFileChange}
              className="college-give-task-form-input"
            />
          </label>
        </div>

        {formData.type === 'Quiz' && renderQuizForm()}

        <button
          type="submit"
          className="college-give-task-submit-btn"
          disabled={loading}
        >
          {loading ? 'Submitting...' : 'Submit Task'}
        </button>

        {successMessage && <div className="college-give-task-success-message">{successMessage}</div>}
        {errorMessage && <div className="college-give-task-error-message">{errorMessage}</div>}
      </form>
    </div>
  );
};

export default GiveTask;