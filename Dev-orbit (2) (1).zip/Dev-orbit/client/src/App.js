import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './AuthContext';

// Home Page Components
import Header from './Home/Header';
import VideoDisplay from './Home/Image';
import DevOrbit from './Home/Devorbit';
import Institutes from './Home/Institutes';
import Dev from './Home/Dev';
import TopProjects from './Home/TopProjects';
import Statistics from './Home/Statistics';
import Footer from './bars/Footer';

// Profile Component
import TaskList from './college_admin/TaskLists';
import CollegeHomepage from "./college_admin/CollegeHomepage";
import CollegeAdminProfile from './college_admin/profile';
import Classes from './college_admin/Classes';
import Teams from './college_admin/Teams';
import MyCalendar from './college_admin/Calendar';
import AddStudent from './college_admin/add-stu';
import Certification from './college_admin/Certification';
import Courses from './college_admin/Courses';

// Student Components
import Student from './student/student';

// Login Components
import AdminLoginForm from './Logins/mcLogin';
import StudentLogin from './Logins/student';
import AdminHomePage from './main_admin/Home';
import ProtectedRoute from './ProtectedRoute';
import SendNotification from './main_admin/notifications';
// Contact Component
import ContactUs from './Contact/Contact';
import Colleges from './main_admin/Colleges';
import AddCollege from './main_admin/add-college';
import AddAdmin from './main_admin/add-admin';
import AdminDashboard from './main_admin/Main-content';
import ProfileSettings from './main_admin/profile';
import NotificationViewer from './college_admin/notifications';
import Dashboard from './college_admin/CollegeDashboard';
// Navbar Component

import StudentHomepage from './student/Home';
import ProjectPage from './student/projects';
import TaskPage from './student/tasks';
import QuizPage from './student/quiz'; // Updated import
import StudentProfile from './student/profile';
import Calendar from './student/calendar';
import Notifications from './student/notifications';
import MyTeam from './student/team';
import ManualStudentAdd from './college_admin/manual-addstu';
import StudentDashboard from './student/StudentDashboard';
// Layout for routes that need Navbar
const MainLayout = ({ children }) => (
  <>
    {children}
  </>
);

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/about" element={<DevOrbit />} />
          <Route path="/manual-addstu" element={<ManualStudentAdd />} />
          <Route path="/TopProjects" element={<TopProjects />} />
          <Route path="/teams" element={<Teams />} />
          {/* Login Route with Navbar */}
          <Route path="/login" element={
            <MainLayout>
              <AdminLoginForm />
            </MainLayout>
          } />

          {/* Student Login Route with Navbar */}
          <Route path="/student/login" element={
            <MainLayout>
              <StudentLogin />
            </MainLayout>
          } />

          {/* Home Routes */}
          <Route path="/" element={
            <>
              <Header />
              <VideoDisplay />
              <DevOrbit />
              <Institutes />
              <Dev />
              <TopProjects />
              <Statistics />
              <Footer />
            </>
          } />

          {/* Contact Route */}
          <Route path="/contact" element={
            <MainLayout>
              <ContactUs />
            </MainLayout>
          } />

          {/* Main Admin Routes */}
          <Route path="/adminHome" element={<AdminHomePage />}>
            <Route index element={<Navigate to="adminDashboard" replace />} />
            <Route path="adminDashboard" element={<AdminDashboard />} />
            <Route path="colleges" element={<Colleges />} />
            <Route path="add-college" element={<AddCollege />} />
            <Route path="add-admin" element={<AddAdmin />} />
            <Route path="mainProfile" element={<ProfileSettings />} />
            <Route path="notifications" element={<SendNotification />} />
          </Route>

          {/* College Admin Profile Routes */}
          <Route path="/college-admin-profile" element={
            <MainLayout>
              <CollegeHomepage />
            </MainLayout>
          }>
            <Route path="dashboard" element={<Dashboard />} />
            <Route path="collegeProfile" element={<CollegeAdminProfile />} />
            <Route path="taskLists" element={<TaskList />} />
            <Route path="adminCalendar" element={<MyCalendar />} />
            <Route path="classes" element={<Classes />} />
            <Route path="notifications" element={<NotificationViewer />} />
            <Route path="add-student" element={<AddStudent />} />
            <Route path="certification" element={<Certification />} />
            <Route path="courses" element={<Courses />} />
            <Route path="student" element={<Student />} />
          </Route>

          {/* Student Routes */}
          <Route path="/student" element={
            <MainLayout>
              <ProtectedRoute />
              <StudentHomepage />
            </MainLayout>
          }>
            <Route path="student-dashboard" element={<StudentDashboard />} />
            <Route path="projects" element={<ProjectPage />} />
            <Route path="tasks" element={<TaskPage />} />
            <Route path="quiz" element={<QuizPage />} />
            <Route path="Calendar" element={<Calendar />} />
            <Route path="certification" />
            <Route path="studentProfile" element={<StudentProfile />} />
            <Route path="team" element={<MyTeam />} />
            <Route path="notifications" element={<Notifications />} />
          </Route>
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;
