import React, { useEffect, useState, useCallback } from 'react';
import axios from 'axios';
import './quiz.css';

const QuizPage = () => {
  const [activeTab, setActiveTab] = useState('active');
  const [quizzes, setQuizzes] = useState([]);
  const [selectedQuiz, setSelectedQuiz] = useState(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState([]);
  const [score, setScore] = useState(0);
  const [quizFinished, setQuizFinished] = useState(false);
  const [timeLeft, setTimeLeft] = useState(60); // 60 sec timer per question
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [fullscreen, setFullscreen] = useState(false); // State to manage fullscreen mode

  useEffect(() => {
    const fetchQuizzes = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get('http://localhost:5000/tasks/quizzes', {
          headers: { Authorization: `Bearer ${token}` }
        });
        setQuizzes(response.data);
        setLoading(false);
      } catch (err) {
        setError('Failed to load quizzes');
        setLoading(false);
      }
    };
    fetchQuizzes();
  }, []);

  const isQuizActive = (quiz) => {
    if (!quiz || !quiz.startDate || !quiz.endDate) return false;

    const now = new Date();
    const startDate = new Date(quiz.startDate);
    const endDate = new Date(quiz.endDate);

    if (quiz.startTime) {
      const startTime = quiz.startTime.split(':');
      startDate.setHours(parseInt(startTime[0]), parseInt(startTime[1]));
    }

    if (quiz.endTime) {
      const endTime = quiz.endTime.split(':');
      endDate.setHours(parseInt(endTime[0]), parseInt(endTime[1]));
    }

    return now >= startDate && now <= endDate;
  };

  const isQuizUpcoming = (quiz) => {
    if (!quiz || !quiz.startDate) return false;

    const now = new Date();
    const startDate = new Date(quiz.startDate);

    if (quiz.startTime) {
      const startTime = quiz.startTime.split(':');
      startDate.setHours(parseInt(startTime[0]), parseInt(startTime[1]));
    }

    return now < startDate;
  };

  useEffect(() => {
    if (selectedQuiz) {
      setAnswers(new Array(selectedQuiz.questions.length).fill(null));
      setTimeLeft(60); // Reset time for each question
    }
  }, [selectedQuiz]);

  useEffect(() => {
    let timer;
    if (!quizFinished && selectedQuiz) {
      if (timeLeft > 0) {
        timer = setInterval(() => {
          setTimeLeft(prevTime => prevTime - 1);
        }, 1000);
      } else {
        // Move to the next question when time is up
        handleNext();
      }
    }
    return () => clearInterval(timer);
  }, [timeLeft, quizFinished, selectedQuiz]);

  const handleAnswerChange = (event) => {
    const updatedAnswers = [...answers];
    updatedAnswers[currentQuestionIndex] = event.target.value;
    setAnswers(updatedAnswers);
  };

  const handleSubmit = useCallback(() => {
    let finalScore = 0;
    selectedQuiz.questions.forEach((question, index) => {
      if (answers[index] === question.correctAnswer) {
        finalScore += 1;
      }
    });
    setScore(finalScore);
    setQuizFinished(true);
    exitFullscreen(); // Exit fullscreen when quiz is submitted
  }, [answers, selectedQuiz]);

  const formatDateTime = (date, time) => {
    if (!date) return 'Date not set';

    const dateObj = new Date(date);
    const formattedDate = dateObj.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
    return time ? `${formattedDate} at ${time}` : formattedDate;
  };

  const handleNext = () => {
    if (currentQuestionIndex < selectedQuiz.questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setTimeLeft(60); // Reset timer for the next question
    }
  };

  const enterFullscreen = () => {
    if (fullscreen) return; // Prevent fullscreen toggle if already in fullscreen
    const doc = document.documentElement;
    if (doc.requestFullscreen) {
      doc.requestFullscreen();
    } else if (doc.webkitRequestFullscreen) {
      doc.webkitRequestFullscreen();
    } else if (doc.mozRequestFullScreen) {
      doc.mozRequestFullScreen();
    } else if (doc.msRequestFullscreen) {
      doc.msRequestFullscreen();
    }
    setFullscreen(true); // Update fullscreen state
  };

  const exitFullscreen = () => {
    const doc = document;
    if (doc.exitFullscreen) {
      doc.exitFullscreen();
    } else if (doc.webkitExitFullscreen) {
      doc.webkitExitFullscreen();
    } else if (doc.mozCancelFullScreen) {
      doc.mozCancelFullScreen();
    } else if (doc.msExitFullscreen) {
      doc.msExitFullscreen();
    }
    setFullscreen(false); // Update fullscreen state
  };

  const handleStartQuiz = () => {
    if (!selectedQuiz || !selectedQuiz.questions) {
      alert('opening quiz!');
      return;
    }

    // Automatically enter fullscreen mode when quiz starts
    enterFullscreen();

    // Initialize the quiz state
    setAnswers(new Array(selectedQuiz.questions.length).fill(null));
    setTimeLeft(60); // Reset time for each question
    setCurrentQuestionIndex(0); // Start from the first question
    setQuizFinished(false); // Reset quiz state
  };

  const renderQuizContent = () => {
    if (!selectedQuiz || !selectedQuiz.questions || !selectedQuiz.questions.length) return null;

    return (
      <div className="student-quiz-content">
        <h2 className="student-quiz-title">{selectedQuiz.title}</h2>
        <h3 className="student-quiz-question-count">Question {currentQuestionIndex + 1} / {selectedQuiz.questions.length}</h3>
        <p className="student-quiz-question">{selectedQuiz.questions[currentQuestionIndex]?.question}</p>
        <form className="student-quiz-options">
          {selectedQuiz.questions[currentQuestionIndex]?.options?.map((option, index) => (
            <div key={index} className="student-quiz-option">
              <input
                type="radio"
                id={`option-${index}`}
                name={`question-${currentQuestionIndex}`}
                value={option}
                checked={answers[currentQuestionIndex] === option}
                onChange={handleAnswerChange}
              />
              <label htmlFor={`option-${index}`} className="student-quiz-option-label">
                {option}
              </label>
            </div>
          ))}
        </form>
        <div className="student-quiz-navigation">
          <button
            onClick={handleNext}
            disabled={currentQuestionIndex === selectedQuiz.questions.length - 1}
            className="student-quiz-nav-button"
          >
            Next
          </button>
          <button
            onClick={handleSubmit}
            className="student-quiz-submit-button"
          >
            Submit Quiz
          </button>
        </div>
        <div className="student-quiz-timer">
          Time Left: {timeLeft} seconds
        </div>
      </div>
    );
  };

  const renderQuizCard = (quiz) => {
    if (!quiz) return null;

    return (
      <div key={quiz._id} className="student-quiz-card">
        <h2 className="student-quiz-card-title">{quiz.title}</h2>
        <div className="student-quiz-card-dates">
          <div>
            <p className="student-quiz-card-date-label">Start:</p>
            <p>{formatDateTime(quiz.startDate, quiz.startTime)}</p>
          </div>
          <div>
            <p className="student-quiz-card-date-label">End:</p>
            <p>{formatDateTime(quiz.endDate, quiz.endTime)}</p>
          </div>
        </div>
        <div className="student-quiz-card-footer">
          <span className="student-quiz-card-question-count">
            {quiz.questions ? `${quiz.questions.length} questions` : 'No questions available'}
          </span>
          {isQuizActive(quiz) && quiz.questions && quiz.questions.length > 0 && (
            <button
              onClick={() => {
                setSelectedQuiz(quiz); // Set the selected quiz to start
                handleStartQuiz();
              }}
              className="student-quiz-start-button"
            >
              Start Quiz
            </button>
          )}
          {isQuizUpcoming(quiz) && (
            <p className="student-quiz-card-status">Quiz upcoming</p>
          )}
          {!isQuizActive(quiz) && !isQuizUpcoming(quiz) && (
            <p className="student-quiz-card-status">Quiz expired</p>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="student-quiz-container">
      <div className="student-quiz-tabs">
        <button
          className={`student-quiz-tab ${activeTab === 'active' ? 'active' : ''}`}
          onClick={() => setActiveTab('active')}
        >
          Active
        </button>
        <button
          className={`student-quiz-tab ${activeTab === 'upcoming' ? 'upcoming' : ''}`}
          onClick={() => setActiveTab('upcoming')}
        >
          Upcoming
        </button>
      </div>

      <div className="student-quiz-list">
        {loading ? (
          <p>Loading quizzes...</p>
        ) : error ? (
          <p>{error}</p>
        ) : (
          quizzes
            .filter(quiz => (activeTab === 'active' ? isQuizActive(quiz) : isQuizUpcoming(quiz)))
            .map(quiz => renderQuizCard(quiz))
        )}
      </div>

      {selectedQuiz && !quizFinished && renderQuizContent()}
      {quizFinished && (
        <div className="student-quiz-results">
          <h3>Your Score: {score} / {selectedQuiz.questions.length}</h3>
        </div>
      )}
    </div>
  );
};

export default QuizPage;
