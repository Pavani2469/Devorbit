import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { Loader2 } from 'lucide-react';
import '../main_admin/profile.css';

function StudentProfile() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [studentData, setStudentData] = useState({
    name: '',
    rollNo: '',
    mail: '',
    class: '',
    githubId: '',
    team: '',
    profilePicture: ''
  });
  const [formData, setFormData] = useState({
    name: '',
    githubId: '',
    team: '',
    profilePicture: null
  });
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchStudentData = async () => {
      const organizationCode = localStorage.getItem('organizationCode');
      const rollNo = localStorage.getItem('rollno');
      const mail = localStorage.getItem('mail');
      const token = localStorage.getItem('token');

      if (!organizationCode || !rollNo || !mail) {
        setError('Missing login credentials. Please login again.');
        setLoading(false);
        return;
      }

      try {
        const response = await axios.get(`http://localhost:5000/profile/${organizationCode}?rollNo=${rollNo}&mail=${mail}`, 
          {
            headers : {
              Authorization : `Bearer ${token}`,
            },
          }
        );
        console.log(response);
        const profile = response.data;
        console.log(profile);

        setStudentData({
          name: profile.name || '',
          rollNo: profile.rollNo || '',
          mail: profile.mail || '',
          class: profile.class || '',
          githubId: profile.githubId || '',
          team: profile.team || '',
          profilePicture: profile.profilePicture || ''
        });

        setFormData({
          name: profile.name || '',
          githubId: profile.githubId || '',
          team: profile.team || '',
          profilePicture: null
        });

      } catch (error) {
        setError('Error loading profile: ' + (error.response?.data?.message || error.message));
      } finally {
        setLoading(false);
      }
    };

    fetchStudentData();
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleFileChange = (e) => {
    setFormData(prev => ({
      ...prev,
      profilePicture: e.target.files[0]
    }));
  };

  const handleProfilePictureUpload = async (file) => {
    const formData = new FormData();
    formData.append('rollNo', studentData.rollNo);
    formData.append('profilePicture', file);

    try {
      await axios.post('http://localhost:5000/student/upload-profile-picture', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
    } catch (error) {
      setError('Error uploading profile picture: ' + (error.response?.data?.message || error.message));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);

    const formDataToSubmit = new FormData();
    formDataToSubmit.append('rollNo', studentData.rollNo);
    formDataToSubmit.append('name', formData.name);
    formDataToSubmit.append('githubId', formData.githubId);
    formDataToSubmit.append('team', formData.team);

    try {
      await axios.post('http://localhost:5000/student/update-profile', formDataToSubmit);

      if (formData.profilePicture) {
        await handleProfilePictureUpload(formData.profilePicture);
        setStudentData(prev => ({
          ...prev,
          profilePicture: URL.createObjectURL(formData.profilePicture)
        }));
      }

      alert('Profile updated successfully!');
    } catch (error) {
      setError('Error updating profile: ' + (error.response?.data?.message || error.message));
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="profile-container">
        <div style={{ textAlign: 'center', width: '100%', padding: '20px' }}>
          <Loader2 className="animate-spin" style={{ margin: 'auto', width: '32px', height: '32px' }} />
          <p>Loading profile...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="profile-container" id="studentProfile">
      <div className="profile-sidebar">
        <img 
          src={studentData.profilePicture ? `http://localhost:5000/${studentData.profilePicture}` : "https://via.placeholder.com/150"} 
          alt="Profile"
        />
        <h3>{studentData.name}</h3>
        <p>{studentData.mail}</p>
        <p>Class: {studentData.class}</p>
      </div>

      <div className="profile-details">
        <h2>Student Profile</h2>
        {error && (
          <div style={{ marginBottom: '20px', padding: '10px', backgroundColor: '#ffe6e6', color: '#ff0000', borderRadius: '5px' }}>
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleInputChange}
              className="form-input"
              placeholder="Full Name"
              required
              disabled={saving}
            />
          </div>

          <div className="form-group">
            <input
              type="text"
              name="githubId"
              value={formData.githubId}
              onChange={handleInputChange}
              className="form-input"
              placeholder="GitHub ID"
              disabled={saving}
            />
          </div>

          <div className="form-group">
            <input
              type="text"
              name="team"
              value={formData.team}
              onChange={handleInputChange}
              className="form-input"
              placeholder="Team"
              disabled={saving}
            />
          </div>

          <div className="form-group">
            <input
              type="file"
              name="profilePicture"
              onChange={handleFileChange}
              className="form-input"
              accept="image/*"
              disabled={saving}
            />
          </div>

          <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end' }}>
            <button
              type="button"
              onClick={() => setFormData({ name: studentData.name, githubId: studentData.githubId, team: studentData.team, profilePicture: null })}
              className="update-button"
              disabled={saving}
              style={{ backgroundColor: '#6c757d' }}
            >
              Cancel
            </button>
            <button
              type="submit"
              className="update-button"
              disabled={saving}
            >
              {saving ? (
                <span style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '5px' }}>
                  <Loader2 className="animate-spin" style={{ width: '16px', height: '16px' }} />
                  Saving...
                </span>
              ) : (
                'Save Changes'
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default StudentProfile;
