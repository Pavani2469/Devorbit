

import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './project.css'; // Import CSS file

const ProjectPage = () => {
  const [projects, setProjects] = useState([]);
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [selectedProjectId, setSelectedProjectId] = useState(null);
  const [githubToken, setGithubToken] = useState('');
  const [repoOwner, setRepoOwner] = useState('');
  const [repoName, setRepoName] = useState('');

  useEffect(() => {
    const fetchProjects = async () => {
      try {
        const token = localStorage.getItem('token');
        const organizationCode = localStorage.getItem('organizationCode');
        const response = await axios.get('http://localhost:5000/tasks/projects', {
          headers: {
            Authorization: `Bearer ${token}`,
            OrganizationCode: organizationCode,
          },
        });
        setProjects(response.data);
      } catch (error) {
        console.error('Error fetching projects:', error);
      }
    };

    fetchProjects();
  }, []);

  const handleFileChange = (event, projectId) => {
    setSelectedFiles([...event.target.files]);
    setSelectedProjectId(projectId);
  };

  const handleUploadToGitHub = async () => {
    if (selectedFiles.length === 0) {
      alert('Please select files or a folder first!');
      return;
    }

    if (!githubToken || !repoOwner || !repoName) {
      alert('Please provide all GitHub details (Token, Repo Owner, Repo Name).');
      return;
    }

    const folderName = prompt('Enter the folder name:');
    if (!folderName) {
      alert('Folder name is required!');
      return;
    }

    try {
      const token = localStorage.getItem('token');
      const organizationCode = localStorage.getItem('organizationCode');
      const formData = new FormData();
      const studentId = localStorage.getItem('userId');

      selectedFiles.forEach((file) => {
        formData.append('files', file);
      });
      formData.append('itemId', selectedProjectId);
      formData.append('folderName', folderName);
      formData.append('githubToken', githubToken);
      formData.append('repoOwner', repoOwner);
      formData.append('repoName', repoName);
      formData.append('studentId', studentId);
      formData.append('category', 'projects');
      formData.append("organizationCode", organizationCode);

      const response = await axios.post(
        'http://localhost:5000/github/upload',
        formData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            OrganizationCode: organizationCode,
            'Content-Type': 'multipart/form-data',
          },
        }
      );

      alert(`Files uploaded successfully: ${response.data.urls.join(', ')}`);
      setSelectedFiles([]);
      setSelectedProjectId(null);
    } catch (error) {
      console.error('Error uploading files to GitHub:', error);
      alert('Failed to upload files to GitHub.');
    }
  };

  const handleDownload = async (filePath, fileName) => {
    try {
      const token = localStorage.getItem('token');
      const organizationCode = localStorage.getItem('organizationCode');
      const response = await axios.get(`http://localhost:5000/${filePath}`, {
        headers: {
          Authorization: `Bearer ${token}`,
          OrganizationCode: organizationCode,
        },
        responseType: 'blob',
      });

      const blob = new Blob([response.data]);
      const url = window.URL.createObjectURL(blob);

      const link = document.createElement('a');
      link.href = url;
      link.download = fileName || 'download';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error downloading file:', error);
    }
  };

  return (
    <div className="project-page">
      <div className="max-w-4xl mx-auto p-4">
        <h1 className="text-2xl font-bold mb-6">Projects</h1>

        <div className="mb-4">
          <input
            type="text"
            placeholder="GitHub Token"
            value={githubToken}
            onChange={(e) => setGithubToken(e.target.value)}
            className="border p-2 w-full mb-2"
          />
          <input
            type="text"
            placeholder="Repository Owner"
            value={repoOwner}
            onChange={(e) => setRepoOwner(e.target.value)}
            className="border p-2 w-full mb-2"
          />
          <input
            type="text"
            placeholder="Repository Name"
            value={repoName}
            onChange={(e) => setRepoName(e.target.value)}
            className="border p-2 w-full mb-2"
          />
        </div>

        {projects.length ? (
          <div className="grid gap-4">
            {projects.map((project) => (
              <div key={project._id} className="border rounded-lg p-4 shadow">
                <h2 className="text-xl font-semibold mb-2">{project.title}</h2>
                <p className="text-gray-600 mb-3">{project.description}</p>
                <div className="flex flex-col gap-2">
                  <p>Start Date: {new Date(project.startDate).toLocaleDateString()}</p>
                  <p>End Date: {new Date(project.endDate).toLocaleDateString()}</p>
                  {project.filePath && (
                    <button
                      onClick={() => handleDownload(project.filePath, project.fileName)}
                      className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition-colors w-fit"
                    >
                      Download {project.fileName}
                    </button>
                  )}
                  <input
                    type="file"
                    multiple
                    webkitdirectory="true"
                    mozdirectory="true"
                    onChange={(event) => handleFileChange(event, project._id)}
                    className="border p-2 mt-2"
                  />
                  {selectedProjectId === project._id && selectedFiles.length > 0 && (
                    <button
                      onClick={handleUploadToGitHub}
                      className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition-colors mt-2"
                    >
                      Upload to GitHub
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-gray-500">No projects available.</p>
        )}
      </div>
    </div>
  );
};

export default ProjectPage;
