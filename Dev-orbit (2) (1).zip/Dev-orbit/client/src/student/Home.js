import React, { useState } from 'react';
import { Link, Outlet } from 'react-router-dom';
import {
  FaHome,
  FaClipboardList,
  FaRegLightbulb,
  FaCalendarAlt,
  FaRegFolderOpen,
  FaBell,
  FaCommentDots,
  FaUserCircle,
  FaTimes,
  FaCertificate,
  FaUsers
} from 'react-icons/fa';
import '../main_admin/Home.css';
import logo from '../images/small.png';
import devLogo from '../images/Logoo.png';
import { BsWindowSidebar } from "react-icons/bs";;

const StudentHomepage = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  
  const toggleSidebar = () => setSidebarOpen(!sidebarOpen);

  return (
    <div className="main-admin-css-page" id="student">
      {/* Top Navbar */}
      <header className="main-admin-css-navbar" style={{ marginLeft: sidebarOpen ? '250px' : '65px' }}>
        <div className="main-admin-css-navbar-content">
          <div className="main-admin-css-left-nav">
            <h1 className='main-admin-css-welcome-text'>Welcome, Student 😀</h1>
          </div>
          <div className="main-admin-css-navbar-icons">
            <Link to="/student/notifications" className="main-admin-css-icon-link" title="Notifications">
              <FaBell className="main-admin-css-icon" />
            </Link>
            <Link to="/student/chat" className="main-admin-css-icon-link" title="Messages">
              <FaCommentDots className="main-admin-css-icon" />
            </Link>
            <Link to="/student/studentProfile" className="main-admin-css-icon-link" title="Profile">
              <FaUserCircle className="main-admin-css-icon" />
            </Link>
          </div>
        </div>
      </header>

      {/* Sidebar */}
      <div
        className={`main-admin-css-sidebar ${sidebarOpen ? 'open' : 'closed'}`}
        onMouseEnter={() => setSidebarOpen(true)}
        onMouseLeave={() => setSidebarOpen(false)}
      >
        <button
          className="main-admin-css-toggle-btn"
          onClick={toggleSidebar}
        >
          {sidebarOpen ? <FaTimes /> : <BsWindowSidebar />}
        </button>
        <div className="main-admin-css-logo">
          {sidebarOpen ? (
            <img src={devLogo} alt="DevOrbit Logo" className="main-admin-css-sidebar-logo-open" />
          ) : (
            <img src={logo} alt="DevOrbit Logo" className="main-admin-css-sidebar-logo" />
          )}
        </div>
        
        <nav className="main-admin-css-nav-menu">
          <ul>
            <li>
              <Link to="/student/student-dashboard" className="main-admin-css-link">
                <FaHome className="main-admin-css-icon" />
                {sidebarOpen && <span>Home</span>}
              </Link>
            </li>
            <li>
              <Link to="/student/projects" className="main-admin-css-link">
                <FaRegFolderOpen className="main-admin-css-icon" />
                {sidebarOpen && <span>Projects</span>}
              </Link>
            </li>
            <li>
              <Link to="/student/tasks" className="main-admin-css-link">
                <FaClipboardList className="main-admin-css-icon" />
                {sidebarOpen && <span>Tasks</span>}
              </Link>
            </li>
            <li>
              <Link to="/student/quiz" className="main-admin-css-link">
                <FaRegLightbulb className="main-admin-css-icon" />
                {sidebarOpen && <span>Quizzes</span>}
              </Link>
            </li>
            <li>
              <Link to="/student/Calendar" className="main-admin-css-link">
                <FaCalendarAlt className="main-admin-css-icon" />
                {sidebarOpen && <span>Calendar</span>}
              </Link>
            </li>
            <li>
              <Link to="/student/team" className="main-admin-css-link">
                <FaUsers className="main-admin-css-icon" />
                {sidebarOpen && <span>My Team</span>}
              </Link>
            </li>
            <li>
              <Link to="/college-admin-profile/certification" className="main-admin-css-link">
                <FaCertificate className="main-admin-css-icon" />
                {sidebarOpen && <span>Certifications</span>}
              </Link>
            </li>
          </ul>
        </nav>
      </div>

      {/* Main Content */}
      <div className="main-admin-css-content" style={{ marginLeft: sidebarOpen ? '250px' : '65px' }}>
        <div className="main-admin-css-home">
          <div className="main-admin-css-welcome-section">
            <Outlet />
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentHomepage;