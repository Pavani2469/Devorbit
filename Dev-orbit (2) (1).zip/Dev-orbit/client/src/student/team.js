import React, { useState, useEffect } from 'react';
import { Table, Card, message } from 'antd';
import axios from 'axios';
import jwtDecode from 'jwt-decode';

const StudentTeamDetails = () => {
  const [teamMembers, setTeamMembers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTeamDetails = async () => {
      try {
        // Get token and decode it to extract organization and class details
        const token = localStorage.getItem('token');
        const decodedToken = jwtDecode(token);
        const { class: className } = decodedToken;
        const { team } = decodedToken;
        // Fetch team members
        const response = await axios.get(`http://localhost:5000/team/${className}/${team}`, {
          headers: { Authorization: `Bearer ${token}` }
        });

        setTeamMembers(response.data);
        setLoading(false);
      } catch (error) {
        message.error('Failed to fetch team details');
        setLoading(false);
      }
    };

    fetchTeamDetails();
  }, []);

  const columns = [
    { title: 'Name', dataIndex: 'name', key: 'name' },
    { title: 'Roll No', dataIndex: 'rollNo', key: 'rollNo' },
    { title: 'Class', dataIndex: 'class', key: 'class' },
    { title: 'Email', dataIndex: 'mail', key: 'mail' },
    { title: 'GitHub ID', dataIndex: 'githubId', key: 'githubId' },
  ];

  return (
    <Card title="Team Members" className="w-full">
      <Table 
        columns={columns} 
        dataSource={teamMembers} 
        rowKey="rollNo"
        loading={loading}
        pagination={{
          pageSize: 10,
          showSizeChanger: true,
          showTotal: (total, range) => `${range[0]}-${range[1]} of ${total} students`
        }}
      />
    </Card>
  );
};

export default StudentTeamDetails;