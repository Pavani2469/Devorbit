import React from "react";
import PropTypes from "prop-types";

const ResultDashboard = ({ results }) => {
  const percentage = ((results.score / results.total) * 100).toFixed(2);

  const getMotivationalMessage = () => {
    if (percentage === 100) {
      return "Perfect score! You're unstoppable!";
    } else if (percentage >= 75) {
      return "Great job! Keep striving for excellence.";
    } else if (percentage >= 50) {
      return "Good effort! Keep pushing forward.";
    } else {
      return "Don't give up! Every attempt makes you stronger.";
    }
  };

  return (
    <div className="dashboard" style={styles.dashboard}>
      <h1 style={styles.heading}>Quiz Results</h1>
      <p style={styles.score}>
        Score: <strong>{results.score}</strong> / {results.total} (
        {percentage}%)
      </p>
      <p style={styles.message}>{getMotivationalMessage()}</p>
    </div>
  );
};

const styles = {
  dashboard: {
    padding: "20px",
    border: "1px solid #ddd",
    borderRadius: "10px",
    backgroundColor: "#f9f9f9",
    textAlign: "center",
    width: "80%",
    margin: "20px auto",
    boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)",
  },
  heading: {
    color: "#4CAF50",
    marginBottom: "15px",
  },
  score: {
    fontSize: "18px",
    margin: "10px 0",
  },
  message: {
    fontSize: "16px",
    color: "#555",
  },
};

ResultDashboard.propTypes = {
  results: PropTypes.shape({
    score: PropTypes.number.isRequired,
    total: PropTypes.number.isRequired,
  }).isRequired,
};

export default ResultDashboard;
