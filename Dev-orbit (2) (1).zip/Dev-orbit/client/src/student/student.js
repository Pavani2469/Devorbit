import React, { useState } from "react";
import Quiz from "./quiz"; // Consistent casing in the import

const App = () => {
  // State to track the current screen and quiz result
  const [currentScreen, setCurrentScreen] = useState("welcome"); // Tracks current screen: "welcome", "quiz", or "finished"
  const [quizResult, setQuizResult] = useState(null);

  // Function to start the quiz
  const startQuiz = () => {
    setCurrentScreen("quiz");
  };

  // Function to finish the quiz and store the result
  const finishQuiz = (result) => {
    setQuizResult(result);
    setCurrentScreen("finished");
  };

  return (
    <div style={{ textAlign: "center", padding: "20px" }}>
      {/* Welcome Screen */}
      {currentScreen === "welcome" && (
        <div>
          <h1>Welcome to the Quiz Application</h1>
          <p>Click below to start the quiz.</p>
          <button
            onClick={startQuiz}
            style={buttonStyle}
          >
            Start Quiz
          </button>
        </div>
      )}

      {/* Quiz Screen */}
      {currentScreen === "quiz" && (
        <Quiz
          quizId="12345" // Replace with the actual quiz ID
          onFinish={finishQuiz}
        />
      )}

      {/* Finished Screen */}
      {currentScreen === "finished" && (
        <div>
          <h1>Quiz Finished</h1>
          <p>Your Score: {quizResult?.score}/{quizResult?.total}</p>
          <p>{quizResult?.message}</p>
          <blockquote>{quizResult?.motivationalQuote}</blockquote>
          <button
            onClick={() => setCurrentScreen("welcome")}
            style={buttonStyle}
          >
            Try Again
          </button>
        </div>
      )}
    </div>
  );
};

// Button styling defined separately for reusability
const buttonStyle = {
  padding: "10px 20px",
  backgroundColor: "#007bff",
  color: "#fff",
  border: "none",
  borderRadius: "5px",
  cursor: "pointer",
};

export default App;
