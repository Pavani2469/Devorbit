import React, { useState, useEffect } from 'react';
import ReactCalendar from 'react-calendar';
import axios from 'axios';

const ReminderCalendar = () => {
  const [date, setDate] = useState(new Date());
  const [reminders, setReminders] = useState({});
  const [selectedReminder, setSelectedReminder] = useState(null);
  const [showReminderDetails, setShowReminderDetails] = useState(false);

  const getAuthHeader = () => {
    const token = localStorage.getItem('token');
    return {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    };
  };

  const fetchReminders = async () => {
    try {
      const { data } = await axios.get(
        'http://localhost:5000/reminder/get-reminder',
        getAuthHeader()
      );
      const remindersObj = {};
      data.forEach(reminder => {
        const reminderDate = new Date(reminder.date).toDateString();
        remindersObj[reminderDate] = {
          description: reminder.description,
          meetingLink: reminder.meetingLink
        };
      });
      setReminders(remindersObj);
    } catch (error) {
      console.error('Error fetching reminders:', error);
      if (error.response?.status === 401) {
        console.log('Unauthorized access. Please login again.');
      }
    }
  };

  useEffect(() => {
    fetchReminders();
  }, []);

  const handleDateChange = (selectedDate) => {
    setDate(selectedDate);
    const formattedDate = selectedDate.toDateString();
    if (reminders[formattedDate]) {
      setSelectedReminder(reminders[formattedDate]);
      setShowReminderDetails(true);
    } else {
      setSelectedReminder(null);
      setShowReminderDetails(false);
    }
  };

  const tileClassName = ({ date }) => {
    const formattedDate = date.toDateString();
    return reminders[formattedDate] ? 'has-reminder' : '';
  };

  const ReminderDetails = () => {
    if (!selectedReminder || !showReminderDetails) return null;

    return (
      <div className="reminder-details-popup">
        <h3>Reminder Details</h3>
        <div className="reminder-details-content">
          <p><strong>Description:</strong> {selectedReminder.description}</p>
          {selectedReminder.meetingLink && (
            <p>
              <strong>Meeting Link:</strong>{' '}
              <a 
                href={selectedReminder.meetingLink} 
                target="_blank" 
                rel="noopener noreferrer"
                className="meeting-link"
              >
                Join Meeting
              </a>
            </p>
          )}
        </div>
        <button 
          className="close-details-btn"
          onClick={() => setShowReminderDetails(false)}
        >
          Close
        </button>
      </div>
    );
  };

  return (
    <div className="calendar-container" id="Calendar">
      <h2 className="calendar-header">Select a Date</h2>
      <ReactCalendar
        onChange={handleDateChange}
        value={date}
        className="reminder-calendar"
        tileClassName={tileClassName}
      />
      {showReminderDetails && <ReminderDetails />}
    </div>
  );
};

export default ReminderCalendar;