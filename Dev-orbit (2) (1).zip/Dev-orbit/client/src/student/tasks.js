import React, { useEffect, useState } from 'react';
import axios from 'axios';

const TaskPage = () => {
  const [tasks, setTasks] = useState([]);
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [selectedTaskId, setSelectedTaskId] = useState(null);
  const [githubToken, setGithubToken] = useState('');
  const [repoOwner, setRepoOwner] = useState('');
  const [repoName, setRepoName] = useState('');

  useEffect(() => {
    const fetchTasks = async () => {
      try {
        const token = localStorage.getItem('token');
        const organizationCode = localStorage.getItem('organizationCode');
        const response = await axios.get('http://localhost:5000/tasks/tasks', {
          headers: {
            Authorization: `Bearer ${token}`,
            OrganizationCode: organizationCode,
          },
        });
        setTasks(response.data);
      } catch (error) {
        console.error('Error fetching tasks:', error);
      }
    };

    fetchTasks();
  }, []);

  const handleFileChange = (event, taskId) => {
    setSelectedFiles([...event.target.files]);
    setSelectedTaskId(taskId);
  };

  const handleUploadToGitHub = async () => {
    if (selectedFiles.length === 0) {
      alert('Please select files or a folder first!');
      return;
    }

    if (!githubToken || !repoOwner || !repoName) {
      alert('Please provide all GitHub details (Token, Repo Owner, Repo Name).');
      return;
    }

    const folderName = prompt('Enter the folder name:');
    if (!folderName) {
      alert('Folder name is required!');
      return;
    }

    try {
      const token = localStorage.getItem('token');
      const organizationCode = localStorage.getItem('organizationCode');
      const formData = new FormData();
      const studentId = localStorage.getItem('userId');

      selectedFiles.forEach((file) => {
        formData.append('files', file);
      });
      formData.append('itemId', selectedTaskId);
      formData.append('folderName', folderName);
      formData.append('githubToken', githubToken);
      formData.append('repoOwner', repoOwner);
      formData.append('repoName', repoName);
      formData.append('studentId', studentId);
      formData.append('category', 'tasks');
      formData.append("organizationCode", organizationCode);
      

      const response = await axios.post(
        'http://localhost:5000/github/upload',
        formData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            OrganizationCode: organizationCode,
            'Content-Type': 'multipart/form-data',
          },
        }
      );

      alert(`Files uploaded successfully: ${response.data.urls.join(', ')}`);
      setSelectedFiles([]);
      setSelectedTaskId(null);
    } catch (error) {
      console.error('Error uploading files to GitHub:', error);
      alert('Failed to upload files to GitHub.');
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-4">
      <h1 className="text-2xl font-bold mb-6">Tasks</h1>

      <div className="mb-4">
        <input
          type="text"
          placeholder="GitHub Token"
          value={githubToken}
          onChange={(e) => setGithubToken(e.target.value)}
          className="border p-2 w-full mb-2"
        />
        <input
          type="text"
          placeholder="Repository Owner"
          value={repoOwner}
          onChange={(e) => setRepoOwner(e.target.value)}
          className="border p-2 w-full mb-2"
        />
        <input
          type="text"
          placeholder="Repository Name"
          value={repoName}
          onChange={(e) => setRepoName(e.target.value)}
          className="border p-2 w-full mb-2"
        />
      </div>

      {tasks.length ? (
        <div className="grid gap-4">
          {tasks.map((task) => (
            <div key={task._id} className="border rounded-lg p-4 shadow">
              <h2 className="text-xl font-semibold mb-2">{task.title}</h2>
              <p className="text-gray-600 mb-3">{task.description}</p>
              <p>Start Date: {new Date(task.startDate).toLocaleDateString()}</p>
              <p>End Date: {new Date(task.endDate).toLocaleDateString()}</p>
              <div>
                <input
                  type="file"
                  multiple
                  webkitdirectory="true"
                  mozdirectory="true"
                  onChange={(event) => handleFileChange(event, task._id)}
                  className="border p-2"
                />
                {selectedTaskId === task._id && selectedFiles.length > 0 && (
                  <button
                    onClick={handleUploadToGitHub}
                    className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition-colors mt-2"
                  >
                    Upload to GitHub
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <p className="text-gray-500">No tasks available.</p>
      )}
    </div>
  );
};

export default TaskPage;
