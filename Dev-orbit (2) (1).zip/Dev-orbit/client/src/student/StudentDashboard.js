// import React, { useEffect, useState } from "react";
// import axios from "axios";
// import './StudentDashboard.css';
// const StudentDashboard = () => {
//     const [studentData, setStudentData] = useState(null);
//     const [loading, setLoading] = useState(true);
//     const [error, setError] = useState(null);

//     useEffect(() => {
//         // Get token, organizationCode, and studentId from localStorage
//         const token = localStorage.getItem("token");
//         const organizationCode = localStorage.getItem("organizationCode");
//         const studentId = localStorage.getItem("userId");

//         if (!token || !organizationCode || !studentId) {
//             setError("Missing authentication details. Please log in again.");
//             setLoading(false);
//             return;
//         }

//         // Fetch student data from backend
//         const fetchStudentData = async () => {
//             try {
//                 const response = await axios.get("http://localhost:5000/student-dashboard", {
//                     headers: {
//                         Authorization: `Bearer ${token}`, // Pass token in Authorization header
//                     },
//                     params: {
//                         organizationCode, // Send organizationCode as a query parameter
//                         studentId, // Send studentId as a query parameter
//                     },
//                 });

//                 setStudentData(response.data);
//             } catch (err) {
//                 setError(err.response?.data?.message || "Error fetching student data.");
//             } finally {
//                 setLoading(false);
//             }
//         };


//         fetchStudentData();
//     }, []);

//     if (loading) return <p>Loading student data...</p>;
//     if (error) return <p className="text-red-500">Error: {error}</p>;

//     // Function to count completed and not completed items
//     const countStatus = (items) => {
//         const total = items.length;
//         const completed = items.filter((item) => item.status === true).length;
//         const notCompleted = total - completed;
//         return { total, completed, notCompleted };
//     };

//     // Destructuring student data
//     const { name, rollNo, class: studentClass, mail, githubId, team, role, projects, tasks, quizzes } = studentData;

//     // Get status counts
//     const projectStats = countStatus(projects);
//     const taskStats = countStatus(tasks);
//     const quizStats = countStatus(quizzes);

//     return (
//         <div className="max-w-2xl mx-auto p-6 bg-white shadow-lg rounded-lg">
//             <h2 className="text-2xl font-bold mb-4">Student Dashboard</h2>

//             {/* Student Information */}
//             <div className="mb-4">
//                 <p><strong>Name:</strong> {name}</p>
//                 <p><strong>Roll No:</strong> {rollNo}</p>
//                 <p><strong>Class:</strong> {studentClass}</p>
//                 <p><strong>Email:</strong> {mail}</p>
//                 <p><strong>GitHub ID:</strong> {githubId || "N/A"}</p>
//                 <p><strong>Team:</strong> {team}</p>
//                 <p><strong>Role:</strong> {role}</p>
//             </div>

//             {/* Status Summary */}
//             <div className="bg-gray-100 p-4 rounded-lg">
//                 <h3 className="text-xl font-semibold mb-2">Progress Overview</h3>

//                 <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
//                     <div className="bg-blue-100 p-3 rounded">
//                         <h4 className="font-medium">Projects</h4>
//                         <p>Total: {projectStats.total}</p>
//                         <p>Completed: {projectStats.completed}</p>
//                         <p>Not Completed: {projectStats.notCompleted}</p>
//                     </div>

//                     <div className="bg-green-100 p-3 rounded">
//                         <h4 className="font-medium">Tasks</h4>
//                         <p>Total: {taskStats.total}</p>
//                         <p>Completed: {taskStats.completed}</p>
//                         <p>Not Completed: {taskStats.notCompleted}</p>
//                     </div>

//                     <div className="bg-yellow-100 p-3 rounded">
//                         <h4 className="font-medium">Quizzes</h4>
//                         <p>Total: {quizStats.total}</p>
//                         <p>Completed: {quizStats.completed}</p>
//                         <p>Not Completed: {quizStats.notCompleted}</p>
//                     </div>
//                 </div>
//             </div>
//         </div>
//     );
// };

// export default StudentDashboard;
import React, { useEffect, useState } from "react";
import axios from "axios";
import './StudentDashboard.css';
const StudentDashboard = () => {
    const [studentData, setStudentData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        // Get token, organizationCode, and studentId from localStorage
        const token = localStorage.getItem("token");
        const organizationCode = localStorage.getItem("organizationCode");
        const studentId = localStorage.getItem("userId");

        if (!token || !organizationCode || !studentId) {
            setError("Missing authentication details. Please log in again.");
            setLoading(false);
            return;
        }

        // Fetch student data from backend
        const fetchStudentData = async () => {
            try {
                const response = await axios.get("http://localhost:5000/student-dashboard", {
                    headers: {
                        Authorization: `Bearer ${token}`, // Pass token in Authorization header
                    },
                    params: {
                        organizationCode, // Send organizationCode as a query parameter
                        studentId, // Send studentId as a query parameter
                    },
                });

                setStudentData(response.data);
            } catch (err) {
                setError(err.response?.data?.message || "Error fetching student data.");
            } finally {
                setLoading(false);
            }
        };

        fetchStudentData();
    }, []);

    if (loading) return <p>Loading student data...</p>;
    if (error) return <p className="text-red-500">Error: {error}</p>;

    // Function to count completed and not completed items
    const countStatus = (items) => {
        const total = items.length;
        const completed = items.filter((item) => item.status === true).length;
        const notCompleted = total - completed;
        return { total, completed, notCompleted };
    };

    // Destructuring student data
    const { name, rollNo, class: studentClass, mail, githubId, team, role, projects, tasks, quizzes } = studentData;

    // Get status counts
    const projectStats = countStatus(projects);
    const taskStats = countStatus(tasks);
    const quizStats = countStatus(quizzes);

    return (
        <div className="dashboard-container">
            <h2>Student Dashboard</h2>

            {/* Student Information */}
            <div className="student-info">
                <p><strong>Name:</strong> {name}</p>
                <p><strong>Roll No:</strong> {rollNo}</p>
                <p><strong>Class:</strong> {studentClass}</p>
                <p><strong>Email:</strong> {mail}</p>
                <p><strong>GitHub ID:</strong> {githubId || "N/A"}</p>
                <p><strong>Team:</strong> {team}</p>
                <p><strong>Role:</strong> {role}</p>
            </div>

            {/* Status Summary */}
            <div className="progress-overview">
                <h3>Progress Overview</h3>

                <div className="progress-grid">
                    <div className="progress-card projects">
                        <h4>Projects</h4>
                        <p>Total: {projectStats.total}</p>
                        <p>Completed: {projectStats.completed}</p>
                        <p>Not Completed: {projectStats.notCompleted}</p>
                    </div>

                    <div className="progress-card tasks">
                        <h4>Tasks</h4>
                        <p>Total: {taskStats.total}</p>
                        <p>Completed: {taskStats.completed}</p>
                        <p>Not Completed: {taskStats.notCompleted}</p>
                    </div>

                    <div className="progress-card quizzes">
                        <h4>Quizzes</h4>
                        <p>Total: {quizStats.total}</p>
                        <p>Completed: {quizStats.completed}</p>
                        <p>Not Completed: {quizStats.notCompleted}</p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default StudentDashboard;
