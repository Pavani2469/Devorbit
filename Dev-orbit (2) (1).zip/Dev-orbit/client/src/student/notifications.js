import React, { useEffect, useState } from 'react';
import jwtDecode from 'jwt-decode';
import './notifications.css';

const Notifications = () => {
  const [notifications, setNotifications] = useState([]);
  const [error, setError] = useState(null);
  const [isVisible, setIsVisible] = useState(true); // Toggle visibility of notifications panel

  const fetchNotifications = async (organizationCode) => {
    try {
      const response = await fetch(`http://localhost:5000/admin/notifications/${organizationCode}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      if (data && data.notifications && Array.isArray(data.notifications)) {
        setNotifications(data.notifications);
      } else {
        console.warn('Invalid data structure:', data);
        setNotifications([]);
      }
      setError(null);
    } catch (error) {
      console.error('Error fetching notifications:', error);
      setError('Failed to fetch notifications');
      setNotifications([]);
    }
  };

  const getOrganizationCodeFromToken = () => {
    const token = localStorage.getItem('token');
    if (token) {
      try {
        const decodedToken = jwtDecode(token);
        return decodedToken.organizationCode;
      } catch (error) {
        console.error('Error decoding token:', error);
        return null;
      }
    }
    return null;
  };

  useEffect(() => {
    const organizationCode = getOrganizationCodeFromToken();
    if (organizationCode && isVisible) {
      fetchNotifications(organizationCode);
    }
  }, [isVisible]);

  const handleClose = () => {
    setIsVisible(false); // Hide notifications when the close button is clicked
  };

  if (!isVisible) {
    return null; // Don't render if notifications are hidden
  }

  return (
    <div className="student-notifications-container">
      {error && <div className="student-notifications-error">Error: {error}</div>}

      {/* Close button */}
      <button className="student-notifications-close" onClick={handleClose}>
        X
      </button>

      <h1 className="student-notifications-title">Notifications</h1>

      {notifications.length === 0 ? (
        <p>No notifications found.</p>
      ) : (
        <ul className="student-notifications-list">
          {notifications.map((notif) => (
            <li key={notif._id} className="student-notifications-item">
              <h4 className="student-notifications-item-title">{notif.title}</h4>
              <p className="student-notifications-item-description">
                {notif.message || notif.description}
              </p>
              <span className="student-notifications-item-date">
                {new Date(notif.createdAt).toLocaleDateString()}
              </span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default Notifications;
