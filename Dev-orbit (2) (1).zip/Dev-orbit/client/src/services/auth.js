// frontend/src/services/auth.js
export const setAuthToken = (token) => {
  if (token) {
    localStorage.setItem('token', token);
    // Store organizationCode from JWT payload
    const payload = JSON.parse(atob(token.split('.')[1]));
    localStorage.setItem('organizationCode', payload.organizationCode);
    localStorage.setItem('name', payload.organizationName);
  } else {
    localStorage.removeItem('token');
    localStorage.removeItem('organizationCode');
    localStorage.removeItem('name');
  }
};

export const getAuthToken = () => {
  return localStorage.getItem('token');
};