import React from 'react';
import { Routes, Route } from 'react-router-dom';
import StudentLogin from './Logins/student';
import StudentProfile from './student/profile';
import ProtectedRoute from './ProtectedRoute';

const StudentRoutes = ({ isAuthenticated }) => {
  return (
    <Routes>
      <Route path="login" element={<StudentLogin />} />
      <Route
        path="studentProfile"
        element={
          <ProtectedRoute isAuthenticated={isAuthenticated}>
            <StudentProfile />
          </ProtectedRoute>
        }
      />
    </Routes>
  );
};

export default StudentRoutes;