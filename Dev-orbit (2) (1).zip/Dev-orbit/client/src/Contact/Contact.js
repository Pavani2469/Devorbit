import React, { useState } from 'react';
import axios from 'axios';
import './Contact.css';
import ct from '../images/contact.jpg';
import Header from '../Home/Header';
import Footer from '../bars/Footer';
const ContactUs = () => {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });

  
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/contact/send', formData);
      alert('Message sent successfully!');
      setFormData({ name: '', email: '', message: '' });
    } catch (error) {
      console.error(error);
      alert('Failed to send message.');
    }
  };

  return (
    <>
    <div className="contact-container">
      <Header/>
    {/* Left Section */}
    <div className="contact-left">
      <div className="contact-image">
        <img src={ct} alt="Contact Us" />
      </div>
     
    </div>
  
    {/* Right Section */}
    <div className="contact-right">
      <form className="contact-form">
        <h1>Contact Us</h1>
        <input type="text" placeholder="Your Name" />
        <input type="email" placeholder="Your Email" />
        <textarea placeholder="Your Message"></textarea>
        <button type="submit" className="send-message">Send Message</button>
      </form>
    </div>
  </div>
  <Footer/>
  </>
  );
  };  
export default ContactUs;
