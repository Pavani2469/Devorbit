import React from 'react';
import { Routes, Route } from 'react-router-dom';
import AdminHomePage from './main_admin/Home';
import AddCollege from './main_admin/add-college';
import AddAdmin from './main_admin/add-admin';
import Colleges from './main_admin/Colleges';
import Footer from './bars/Footer';
import ProtectedRoute from './ProtectedRoute';

const MainAdminRoutes = ({ isAuthenticated }) => {
  return (
    <>
      <Routes>
        {/* Base route for main admin */}
        <Route
          path=""
          element={
            <ProtectedRoute 
              isAuthenticated={isAuthenticated}
              allowedUserTypes={['mainAdmin']}
            >
              <AdminHomePage />
            </ProtectedRoute>
          }
        />
        <Route
          path="add-college"
          element={
            <ProtectedRoute 
              isAuthenticated={isAuthenticated}
              allowedUserTypes={['mainAdmin']}
            >
              <AddCollege />
            </ProtectedRoute>
          }
        />
        <Route
          path="add-admin"
          element={
            <ProtectedRoute 
              isAuthenticated={isAuthenticated}
              allowedUserTypes={['mainAdmin']}
            >
              <AddAdmin />
            </ProtectedRoute>
          }
        />
        <Route
          path="colleges"
          element={
            <ProtectedRoute 
              isAuthenticated={isAuthenticated}
              allowedUserTypes={['mainAdmin']}
            >
              <Colleges />
            </ProtectedRoute>
          }
        />
      </Routes>
      <Footer />
    </>
  );
};

export default MainAdminRoutes;
