// AdvisorsSection.jsx
import React from 'react';
import './ProgramOrganizer.css'; // Optional: For CSS styles

const advisors = [
  {
    name: "Ramesh Loganathan",
    title: "Professor of Practice, Co-Innovation, IIIT-Hyderabad.",
    image: "ramesh.jpg", // Replace with actual URL
    alt: "Ramesh Loganathan"
  },
  {
    name: "P Viswam",
    title: "Chairman, KIET Group of Institutions-korangi.",
    image: "vish.jpg", // Replace with actual URL
    alt: "P Viswam"
  },
  {
    name: "D Revathi",
    title: "Principal, KIET-korangi.",
    image: "revathi.jpg", // Replace with actual URL
    alt: "D Revathi"
  },
  {
    name: "Y Rama Krishna",
    title: "Principal, KIET W-korangi.",
    image: "rama.jpg", // Replace with actual URL
    alt: "Y Rama Krishna"
  }
];

const AdvisorsSection = () => {
  return (
    <div className="advisors-container">
      <h2 className="section-title">Program Advisors</h2>
      <div className="advisors-list">
        {advisors.map((advisor, index) => (
          <div className="advisor-card" key={index}>
            <img
              src={advisor.image}
              alt={advisor.alt}
              className="advisor-image"
            />
            <h3 className="advisor-name">{advisor.name}</h3>
            <p className="advisor-title">{advisor.title}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdvisorsSection;