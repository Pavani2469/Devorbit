import React from 'react';
import './Dev.css'; // Ensure you update this CSS file accordingly

const WhyDevOrbit = () => {
  return (
    <section className="home-why-devorbit" >
      <h2>Why DevOrbit</h2>
      <p>
        DevOrbit is a comprehensive, open-source educational management platform built to simplify 
        and enhance the learning experience for colleges and institutes. Inspired by industry-leading 
        tools such as Google Classroom, Quizr, Discord, and Swecha LMS, DevOrbit brings together all 
        the essential features in a single, user-friendly environment. Whether it’s managing assessments, 
        fostering team collaborations, facilitating discussions, or keeping track of notifications, 
        DevOrbit offers a seamless, centralized solution for both students and educators. Our platform is 
        designed to promote efficient learning, collaboration, and project management, all while ensuring 
        flexibility and accessibility for educational institutions.
      </p>
    </section>
  );
};

export default WhyDevOrbit;
