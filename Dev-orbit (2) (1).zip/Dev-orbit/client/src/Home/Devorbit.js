import React from 'react';
import './DevOrbit.css'; // Ensure this CSS file is updated
import home from '../images/home.png';
const WhyDevOrbit = () => {
  return (
    <section className="home-why-devorbit" id="about">
      <div className="home-devorbit-content">
        <div className="home-head">
          <h2>About Us</h2>
        </div>
        <div className="home-content">
          <div className="home-text">
            <p>
              DevOrbit is a comprehensive, open-source educational management platform built to simplify
              and enhance the learning experience for colleges and institutes. Inspired by industry-leading
              tools such as Google Classroom, Quizr, Discord, and Swecha LMS, DevOrbit brings together all
              the essential features in a single, user-friendly environment. Whether it’s managing assessments,
              fostering team collaborations, facilitating discussions, or keeping track of notifications,
              DevOrbit offers a seamless, centralized solution for both students and educators. Our platform is
              designed to promote efficient learning, collaboration, and project management, all while ensuring
              flexibility and accessibility for educational institutions.
            </p>
          </div>
          <div className="home-image">
            <img
              src={home}
              alt="DevOrbit Overview"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhyDevOrbit;
