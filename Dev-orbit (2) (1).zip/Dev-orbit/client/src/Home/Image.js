import React from 'react';
import './Image.css';

const VideoDisplay = () => {
  return (
    <div className="home-video-container" id="home-container">
      {/* Embed the video to behave like a GIF */}
      <video
        src="Devorbit.mp4"
        autoPlay
        loop
        muted
        className="home-responsive-video"
      />
    </div>
  );
};

export default VideoDisplay;