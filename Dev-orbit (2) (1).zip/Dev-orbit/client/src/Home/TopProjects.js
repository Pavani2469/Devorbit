import React from 'react';
import './TopProjects.css';

const TopProjects = () => {
  const projects = [
    {
      id: 1,
      img: 'music.png',
      title: 'Music Recommendation System',
      description: 'A system that suggests music based on user preferences and listening history.',
      organization: 'DevOrbit Labs',
      review: 'Highly accurate and user-friendly.'
    },
    {
      id: 2,
      img: 'music.png',
      title: 'AI Chatbot',
      description: 'An intelligent chatbot for customer support.',
      organization: 'TechNext Solutions',
      review: 'Provides quick responses and handles queries effectively.'
    },
    {
      id: 3,
      img: 'music.png',
      title: 'E-commerce Analytics Dashboard',
      description: 'A dashboard to visualize e-commerce data and trends.',
      organization: 'DataVision Analytics',
      review: 'Easy to use with powerful insights.'
    },
    {
      id: 4,
      img: 'music.png',
      title: 'Smart Home Automation',
      description: 'A system to control home devices remotely.',
      organization: 'IoT Innovations',
      review: 'Seamlessly integrates with multiple devices.'
    },
    {
      id: 5,
      img: 'music.png',
      title: 'Healthcare Monitoring System',
      description: 'A solution to monitor patient health remotely.',
      organization: 'MediTech Solutions',
      review: 'Highly reliable and user-friendly interface.'
    }
  ];

  return (
    <section className="home-top-projects" id="TopProjects">
      <h2>Top Projects</h2>
      <div className="home-projects-carousel">
        <div className="home-projects-track">
          {[...projects, ...projects].map((project, index) => (
            <div className="home-project" key={index}>
              <img src={project.img} alt={project.title} />
              <h3>{project.title}</h3>
              <p>{project.description}</p>
              <p><strong>Organization:</strong> {project.organization}</p>
              <p><strong>Review:</strong> {project.review}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TopProjects;
