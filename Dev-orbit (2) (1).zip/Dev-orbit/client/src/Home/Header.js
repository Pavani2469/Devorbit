import React from 'react';
import { Link } from 'react-router-dom';
import './Header.css';

const Header = () => {
  return (
    <header className="home-header">
      <div className="home-header-logo">
        <img src="Logoo.png" alt="DevOrbit Logo" className="home-logo" /> {/* Logo */}
      </div>
      <nav className="homee-navbar">
        <ul>
          <li><Link to="/" >Home</Link></li>
          <li><a href="#about">About Us</a></li>
          <li><a href="#TopProjects">Projects</a></li>
          <li><Link to="/contact">Contact</Link></li>
          <li><Link to="/student/login">Login</Link></li>
        </ul>
      </nav>
    </header>
  );
};

export default Header;
