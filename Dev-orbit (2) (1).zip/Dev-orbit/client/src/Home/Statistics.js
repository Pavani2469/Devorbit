import React from 'react';
import './Statistics.css';

const Statistics = () => {
  return (
    <section className="home-statistics">
      <h2>Statistics</h2>
      <div className="home-statistics-icons">
        <div className="home-stat-item">
          <img src="college.png" alt="Colleges" />
          <p>Colleges</p>
          <p>5+</p>
        </div>
        <div className="home-stat-item">
          <img src="student.png" alt="Students" />
          <p>Students</p>
          <p>500+</p>
        </div>
        <div className="home-stat-item">
          <img src="certi.png" alt="Certifications" />
          <p>Certifications</p>
          <p>500+</p>
        </div>
        <div className="home-stat-item">
          <img src="team.png" alt="Teams" />
          <p>Teams</p>
          <p>50+</p>
        </div>
        <div className="home-stat-item">
          <img src="projects 1.png" alt="Projects" />
          <p>Projects</p>
          <p>50+</p>
        </div>
      </div>
    </section>
  );
};

export default Statistics;
