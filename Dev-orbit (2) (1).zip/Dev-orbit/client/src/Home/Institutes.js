import React from 'react';
import './Institutes.css';

const Institutes = () => {
  return (
    <section className="home-institutes">
      <h2>Collaborated Institutes</h2>
      <div className="home-institute-logos">
        <img src="logo.png" alt="KIET" />
        <img src="aditya.png" alt="Aditya" />
        <img src="pydah.png" alt="Pydah" />
        <img src="ideal.png" alt="Ideal" />
      </div>
    </section>
  );
};

export default Institutes;
