import React from 'react';
import { Routes, Route } from 'react-router-dom';
import AddStudent from './college_admin/add-stu';
import GiveTask from './college_admin/give-task';
import CollegeAdminProfile from './college_admin/profile';
import Footer from './bars/Footer';
import ProtectedRoute from './ProtectedRoute';

const CollegeAdminRoutes = ({ isAuthenticated }) => {
  return (
    <>
      <Routes>
        <Route
          path=""
          element={
            <ProtectedRoute 
              isAuthenticated={isAuthenticated}
              allowedUserTypes={['collegeAdmin']}
            >
              <CollegeAdminProfile />
            </ProtectedRoute>
          }
        />
        <Route
          path="add-student"
          element={
            <ProtectedRoute 
              isAuthenticated={isAuthenticated}
              allowedUserTypes={['collegeAdmin']}
            >
              <AddStudent />
            </ProtectedRoute>
          }
        />
        <Route
          path="give-task"
          element={
            <ProtectedRoute 
              isAuthenticated={isAuthenticated}
              allowedUserTypes={['collegeAdmin']}
            >
              <GiveTask />
            </ProtectedRoute>
          }
        />
      </Routes>
      <Footer />
    </>
  );
};

export default CollegeAdminRoutes;