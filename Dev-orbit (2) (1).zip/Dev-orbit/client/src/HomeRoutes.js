import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './Home/Header';
import Image from './Home/Image';
import DevOrbit from './Home/Devorbit';
import Institutes from './Home/Institutes';
import Dev from './Home/Dev';
import TopProjects from './Home/TopProjects';
import Statistics from './Home/Statistics';
import Footer from './bars/Footer';
import ContactUs from './Contact/Contact';
import StudentLogin from './Logins/student';
const HomeRoutes = () => {
  return (
    <>
      <Header />
      <Routes>
        <Route
          path="/"
          element={
            <>
              <Image />
              <DevOrbit />
              <Institutes />
              <Dev />
              <TopProjects />
              <Statistics />
              <Footer />
            </>
          }
        />
        <Route path="/contact" element={<ContactUs />} />
        <Route path="/student/login" element={<StudentLogin />} />
      </Routes>
    </>
  );
};

export default HomeRoutes;
