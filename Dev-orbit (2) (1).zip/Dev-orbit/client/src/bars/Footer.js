import React from "react";
import { FaInstagram, FaLinkedin, FaTwitter, FaGlobe, FaEnvelope, FaUserCircle } from "react-icons/fa";
import "./Footer.css";
import { Link } from 'react-router-dom';
const Footer = () => {
  return (
    <div className="footer" id="admin">
      {/* Left Section */}
      <div className="footer-left">
        <h2 className="footer-title">Get in Touch</h2>
        <p className="footer-description">
          Ecosystem bootstrapping learning curve lean startup disruptive.
        </p>
        <div className="footer-icons">
          <a href="https://instagram.com" className="icon" target="_blank" rel="noopener noreferrer">
            <FaInstagram />
          </a>
          <a href="https://linkedin.com" className="icon" target="_blank" rel="noopener noreferrer">
            <FaLinkedin />
          </a>
          <a href="https://twitter.com" className="icon" target="_blank" rel="noopener noreferrer">
            <FaTwitter />
          </a>
          {/* Replacing Pinterest with Profile */}
          <Link to="/login" className="icon">
            <FaUserCircle />
          </Link>
        </div>
      </div>

      {/* Right Section */}
      <div className="footer-right">
        {/* Card 1 */}
        <div className="footer-card">
          <FaGlobe className="footer-card-icon" />
          <a
            href="https://devorbit.com"
            className="footer-card-link"
            target="_blank"
            rel="noopener noreferrer"
          >
            DevOrbit.com
          </a>
        </div>

        {/* Card 2 */}
        <div className="footer-card">
          <FaEnvelope className="footer-card-icon" />
          <a
            href="mailto:devorbit525@gmail.com"
            className="footer-card-link"
          >
            devorbit525@gmail.com
          </a>
        </div>
      </div>
    </div>
  );
};

export default Footer;
