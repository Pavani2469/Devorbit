import React from 'react';
import { Link } from 'react-router-dom';
import { FaBars, FaTimes, FaBell, FaCommentDots, FaUserCircle } from 'react-icons/fa';
import './Navbar.css';

const Navbar = ({ sidebarOpen, setSidebarOpen }) => {
  // Function to handle icon clicks
  const handleIconClick = (iconName) => {
    alert(`Please Login to access ${iconName}`);
  };

  // Function to handle menu toggle
  const handleMenuToggle = () => {
    alert('Please Login to access the Menu');
    if (typeof setSidebarOpen === 'function') {
      setSidebarOpen(!sidebarOpen);
    } else {
      console.warn('setSidebarOpen is not a valid function');
    }
  };

  return (
    <header className="navbar">
      <div className="left-nav">
        <button className="toggle-btn" onClick={handleMenuToggle}>
          {sidebarOpen ? <FaTimes /> : <FaBars />}
        </button>
      </div>
      <div className="right-nav">
        <div className="navbar-icons">
          <Link
            to=""
            className="icon-link"
            title="Notifications"
            onClick={() => handleIconClick('Notifications')}
          >
            <FaBell className="icon" />
          </Link>
          <Link
            to=""
            className="icon-link"
            title="Messages"
            onClick={() => handleIconClick('Messages')}
          >
            <FaCommentDots className="icon" />
          </Link>
          <Link
            to=""
            className="icon-link"
            title="Profile"
            onClick={() => handleIconClick('Profile')}
          >
            <FaUserCircle className="icon" />
          </Link>
        </div>
      </div>
    </header>
  );
};

export default Navbar;