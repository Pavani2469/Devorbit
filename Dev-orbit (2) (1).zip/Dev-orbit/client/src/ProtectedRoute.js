import React from 'react';
import { Navigate } from 'react-router-dom';

const ProtectedRoute = ({ children }) => {
  // Retrieve the JWT token from localStorage
  const token = localStorage.getItem('token');

  if (!token) {
    // If no token, redirect to login
    return <Navigate to="/login" />;
  }

  try {
    // Optional: Decode the token to verify its structure and expiration
    const payload = JSON.parse(atob(token.split('.')[1])); // Decode the JWT payload
    const isExpired = payload.exp * 1000 < Date.now();

    if (isExpired) {
      localStorage.removeItem('token'); // Remove expired token
      return <Navigate to="/login" />;
    }
  } catch (error) {
    console.error('Invalid token:', error);
    return <Navigate to="/login" />;
  }

  // If token is valid, render the children
  return children;
};

export default ProtectedRoute;
