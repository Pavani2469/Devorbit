const mongoose = require('mongoose');
require('dotenv').config(); // Load environment variables from .env

// Default connection to MongoDB Atlas database
const connectToDB = async () => {
  try {
    const mongoURI = process.env.MONGODB_URI; // Get the MongoDB URI from environment variable

    if (!mongoURI) {
      console.error('MongoDB URI is missing in the .env file');
      process.exit(1); // Exit process if URI is not found
    }

    await mongoose.connect(mongoURI, {
      dbName: process.env.DB_NAME || 'test', // Optionally specify the database name
    });

    console.log('Connected to MongoDB Atlas Database');
  } catch (error) {
    console.error('Could not connect to MongoDB Atlas Database:', error.message);
    process.exit(1); // Exit process if connection fails
  }
};

module.exports = { connectToDB };