
const nodemailer = require('nodemailer');
require('dotenv').config();

// Generate OTP (6-digit random number)
const generateOTP = () => Math.floor(100000 + Math.random() * 900000);

/**
 * Send email with either OTP or credentials
 * @param {Object} params - Email parameters
 * @param {string} params.email - Recipient email address
 * @param {string} [params.otp] - OTP code (required for OTP emails)
 * @param {string} [params.rollNo] - Roll number (required for credential emails)
 * @param {string} [params.password] - Password (required for credential emails)
 * @param {boolean} [params.isOtpEmail=true] - Whether this is an OTP email
 */
const sendEmail = async ({ email, otp, rollNo, password, isOtpEmail = true, organizationCode }) => {
  console.log('Inside sendEmail function:');
  console.log('Email:', email);
  console.log('Is OTP Email:', isOtpEmail);

  // Validate required parameters
  if (!email) {
    throw new Error('Email is required');
  }

  if (isOtpEmail && !otp) {
    throw new Error('OTP is required for OTP emails');
  }

  if (!isOtpEmail && (!rollNo || !password || !organizationCode)) {
    throw new Error('Roll number,password and organization code  are required for credential emails');
  }

  // Configure Nodemailer transport
  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS,
    },
    tls: {
      rejectUnauthorized: false, // Bypass self-signed certificate validation
    },
  });

  let mailOptions;

  if (isOtpEmail) {
    mailOptions = {
      from: process.env.EMAIL_USER,
      to: email,
      subject: 'Your OTP Code',
      text: `Your OTP code is: ${otp}`,
      html: `
        <h2>Your OTP Code</h2>
        <p>Your OTP code is: <strong>${otp}</strong></p>
        <p>This code will expire in 10 minutes.</p>
      `,
    };
  } else {
    mailOptions = {
      from: process.env.EMAIL_USER,
      to: email,
      subject: 'Your Student Credentials',
      text: `Your Organization Code: ${organizationCode}\nYour roll number is: ${rollNo}\n\nYour login credentials are:\nEmail: ${email}\nPassword: ${password}`,
      html: `
        <h2>Your Student Credentials</h2>
        <p>Organization Code: <strong>${organizationCode}</strong></p>
        <p>Your roll number is: <strong>${rollNo}</strong></p>
        <p>Your login credentials are:</p>
        <ul>
          <li>Email: ${email}</li>
          <li>Password: ${password}</li>
        </ul>
      `,
    };
  }

  try {
    console.log(`Sending ${isOtpEmail ? 'OTP' : 'credentials'} email...`);
    await transporter.sendMail(mailOptions);
    console.log('Email sent successfully');
    return true;
  } catch (error) {
    console.error('Error sending email:', error);
    throw error;
  }
};

module.exports = {
  sendEmail,
  generateOTP,
};
