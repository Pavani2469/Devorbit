const jwt = require('jsonwebtoken');
require('dotenv').config();

// Middleware for logging requests
const logger = (req, res, next) => {
  console.log(`${req.method} request for '${req.url}'`);
  next();
};

// Middleware for handling errors
const errorHandler = (err, req, res, next) => {
  console.error(err.stack); // Log the error stack trace
  res.status(err.status || 500).json({ message: err.message || 'Something went wrong!' });
};

// Middleware for authenticating JWT tokens
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'Access denied. No token provided.' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded; // Attach decoded data to the request object
    next();
  } catch (error) {
    return res.status(403).json({ message: 'Invalid or expired token.' });
  }
};

module.exports = {
  logger,
  errorHandler,
  authenticateToken
};
