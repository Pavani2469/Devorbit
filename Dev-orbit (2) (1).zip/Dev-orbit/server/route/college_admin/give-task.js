// backend/routes/tasks.js
const express = require('express');
const multer = require('multer');
const path = require('path');
const jwt = require('jsonwebtoken');
const { Item } = require('../../schema/college_admin/give-task');
const Student = require('../../schema/college_admin/studentExcel');
const router = express.Router();
const mongoose = require('mongoose');
require('dotenv').config();

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/'),
  filename: (req, file, cb) => cb(null, `${Date.now()}${path.extname(file.originalname)}`)
});

const upload = multer({ storage });

const verifyToken = (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ message: 'No valid authorization header found' });
    }

    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    req.organizationCode = decoded.organizationCode;
    next();
  } catch (error) {
    console.error('Token verification error:', error);
    return res.status(401).json({ message: 'Invalid or expired token' });
  }
};

const getDynamicModel = (organizationCode, schema) => {
  const collectionName = `${organizationCode}_uploads`;
  return mongoose.models[collectionName] || mongoose.model(collectionName, schema);
};

router.post('/add-item', verifyToken, upload.single('file'), async (req, res) => {
  try {


    const DynamicItem = getDynamicModel(req.organizationCode, Item.schema);

    const itemData = {
      type: req.body.type,
      title: req.body.title,
      startDate: req.body.startDate,
      endDate: req.body.endDate,
      organizationCode: req.organizationCode // Ensure organizationCode is included
    };

    if (req.file) itemData.filePath = req.file.path;
    if (req.body.type !== 'Quiz') itemData.description = req.body.description;
    if (req.body.type === 'Quiz') {
      itemData.questions = JSON.parse(req.body.questions); // Parse questions field
      itemData.startTime = req.body.startTime;
      itemData.endTime = req.body.endTime;

      if (!itemData.startTime || !itemData.endTime) {
        return res.status(400).json({ message: 'Start and end times are required for a quiz.' });
      }
    }

    const newItem = new DynamicItem(itemData);
    await newItem.save();

    // Determine the update field based on the type
    let updateField = '';
    if (req.body.type === 'Project') {
      updateField = 'projects';
    } else if (req.body.type === 'Task') {
      updateField = 'tasks';
    } else if (req.body.type === 'Quiz') {
      updateField = 'quizzes';
    }

    if (updateField) {
      const BranchModel = mongoose.model(
        'Student', // Model name
        Student.schema, // Schema
        req.organizationCode // Dynamically set the collection name
      );

      const result = await BranchModel.updateMany(
        {}, // Filter by organizationCode
        { $push: { [updateField]: { itemId: newItem._id, status: false } } } // Update the appropriate field
      );
      console.log(newItem._id);

      if (result.modifiedCount === 0) {
        return res.status(400).json({ message: 'No students updated.' });
      }
    }

    res.status(201).json({ message: 'Item added successfully!', data: newItem });
  } catch (error) {
    console.error('Error adding item:', error);
    res.status(500).json({ message: 'Failed to add item', error: error.message });
  }
});

// Separate routes for projects, quizzes, and tasks
router.get('/projects', verifyToken, async (req, res) => {
  try {
    const DynamicItem = getDynamicModel(req.organizationCode, Item.schema);
    const projects = await DynamicItem.find({ type: 'Project' }); // Filter by type "Project"
    res.status(200).json(projects);
  } catch (error) {
    console.error('Error fetching projects:', error);
    res.status(500).json({ message: 'Failed to fetch projects', error: error.message });
  }
});

router.get('/quizzes', verifyToken, async (req, res) => {
  try {
    const DynamicItem = getDynamicModel(req.organizationCode, Item.schema);
    const quizzes = await DynamicItem.find({ type: 'Quiz' }); // Filter by type "Quiz"
    res.status(200).json(quizzes);
  } catch (error) {
    console.error('Error fetching quizzes:', error);
    res.status(500).json({ message: 'Failed to fetch quizzes', error: error.message });
  }
});

router.get('/tasks', verifyToken, async (req, res) => {
  try {
    const DynamicItem = getDynamicModel(req.organizationCode, Item.schema);
    const tasks = await DynamicItem.find({ type: 'Task' }); // Filter by type "Task"
    res.status(200).json(tasks);
  } catch (error) {
    console.error('Error fetching tasks:', error);
    res.status(500).json({ message: 'Failed to fetch tasks', error: error.message });
  }
});

// DELETE: Remove an item by ID
router.delete('/delete-item/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const deletedItem = await Item.findByIdAndDelete(id); // Correct method
    if (!deletedItem) {
      return res.status(404).json({ message: 'Item not found!' });
    }
    res.status(200).json({ message: 'Item deleted successfully!' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to delete item', error });
  }
});
router.get('/:filePath', (req, res) => {
  try {
    const filePath = path.join(__dirname, '../../', req.params.filePath);
    const fileExtension = path.extname(filePath).toLowerCase();

    // Map file extensions to MIME types
    const mimeTypes = {
      '.png': 'image/png',
      '.jpg': 'image/jpeg',
      '.jpeg': 'image/jpeg',
      '.gif': 'image/gif',
      '.pdf': 'application/pdf',
      '.txt': 'text/plain',
      '.doc': 'application/msword',
      '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      '.xls': 'application/vnd.ms-excel',
      '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      '.csv': 'text/csv',
      // Add more mappings as needed
    };

    const mimeType = mimeTypes[fileExtension] || 'application/octet-stream'; // Fallback to binary data

    res.setHeader('Content-Type', mimeType);
    res.download(filePath, path.basename(filePath), (err) => {
      if (err) {
        console.error('Error downloading file:', err);
        res.status(500).send('Failed to download file');
      }
    });
  } catch (error) {
    console.error('Error processing file download:', error);
    res.status(500).json({ message: 'Error downloading file', error: error.message });
  }
});

module.exports = router;
