const express = require('express');
const mongoose = require('mongoose');
const router = express.Router();
const Student = require('../../schema/student');


  

// Fetch distinct class names
router.get('/classes', async (req, res) => {

    try {
        const organizationCode = req.query.organizationCode;
        console.log(organizationCode);
        if (!organizationCode) {
            return res.status(400).json({ error: 'Organization code is required.' });
        }

        const ClassModel = mongoose.model(organizationCode, Student.schema, organizationCode);
        const classes = await ClassModel.distinct('class');
        res.status(200).json(classes);
    } catch (error) {
        console.error('Error fetching classes:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

// Fetch teams in a specific class
router.get('/:className/teams', async (req, res) => {
    try {
        const { className } = req.params;
        const organizationCode = req.query.organizationCode;
        if (!organizationCode) {
            return res.status(400).json({ error: 'Organization code is required.' });
        }

        const ClassModel = mongoose.model(organizationCode, Student.schema, organizationCode);
        const teams = await ClassModel.distinct('team', { class: className });
        res.status(200).json(teams);
    } catch (error) {
        console.error('Error fetching teams:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

// Fetch students in a specific team
router.get('/team/:className/:teamName', async (req, res) => {
    try {
        const { className, teamName } = req.params;
        const organizationCode = req.query.organizationCode;
        console.log(className, teamName, organizationCode);

        // Check if organizationCode is provided
        if (!organizationCode) {
            return res.status(400).json({ error: 'Organization code is required.' });
        }

        // Dynamically select the model based on the organization code
        const ClassModel = mongoose.model(organizationCode, Student.schema, organizationCode);

        // Query for students belonging to the specified class and team
        const students = await ClassModel.find({ team: teamName, class: className });
        

        // Send the response
        res.status(200).json(students);
    } catch (error) {
        console.error('Error fetching team data:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});


module.exports = router;
