const express = require('express');
const mongoose = require('mongoose');
const Notification = require('../../schema/notifications'); // Assuming the schema is saved as `notification.js`
const { authenticateToken } = require('../../middleware'); // Assuming the middleware is extracted to a separate file
const router = express.Router();

// **Route to Send Notifications**
router.post('/send-notification', authenticateToken, async (req, res) => {
  const { title, message } = req.body;
  const organizationCode = req.user.organizationCode; // Extracted from the JWT token

  if (!title || !message) {
    return res.status(400).json({ error: 'Title and message are required.' });
  }

  try {
    const notification = new Notification({
      organizationCode,
      title,
      message,
    });

    await notification.save();

    res.status(201).json({ message: 'Notification sent successfully.', notification });
  } catch (error) {
    console.error('Error sending notification:', error);
    res.status(500).json({ error: 'An error occurred while sending the notification.' });
  }
});

// **Route to Get Notifications**
router.get('/get-notifications', authenticateToken, async (req, res) => {
  const organizationCode = req.user.organizationCode; // Extracted from the JWT token

  try {
    const notifications = await Notification.find({ organizationCode })
      .sort({ createdAt: -1 }); // Sort by newest first

    if (notifications.length === 0) {
      return res.status(404).json({ message: 'No notifications found.' });
    }

    res.status(200).json(notifications);
  } catch (error) {
    console.error('Error fetching notifications:', error);
    res.status(500).json({ error: 'An error occurred while fetching notifications.' });
  }
});

module.exports = router;
