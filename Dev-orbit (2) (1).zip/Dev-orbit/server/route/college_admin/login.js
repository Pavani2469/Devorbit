require('dotenv').config();
const express = require('express');
const bcrypt = require('bcrypt');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { sendEmail, generateOTP } = require('../../sendEmail');
const CollegeAdmin = require('../../schema/college_admin/login');
const router = express.Router();

const JWT_SECRET = process.env.JWT_SECRET;
let currentOtp;
const OTP_EXPIRATION_TIME = 5 * 60 * 1000;
let otpTimeout;

// Verify JWT middleware
const verifyToken = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) {
    return res.status(401).json({ message: 'Access denied. No token provided.' });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    return res.status(401).json({ message: 'Invalid token.' });
  }
};

// Configure multer for profile picture uploads
// In your college admin routes file
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = 'uploads/collegeadmin-profile-pictures';
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    cb(null, `${req.user.organizationCode}-${Date.now()}-${Math.round(Math.random() * 1E9)}${path.extname(file.originalname)}`);
  }
});
const upload = multer({
  storage: storage,
  limits: {
    fileSize: 5 * 1024 * 1024 // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);

    if (extname && mimetype) {
      return cb(null, true);
    }
    cb(new Error('Only .png, .jpg and .jpeg format allowed!'));
  }
});

// Registration Route
router.post('/register', async (req, res) => {
  const { 
    organizationName, 
    organizationCode, 
    organizationMail, 
    websiteHandlerName, 
    websiteHandlerMail, 
    websiteHandlerPhoneNumber, 
    password 
  } = req.body;

  try {
    const existingAdmin = await CollegeAdmin.findOne({ organizationCode });
    const existingMail = await CollegeAdmin.findOne({ organizationMail });

    if (existingAdmin || existingMail) {
      return res.status(400).json({ message: 'Organization code or email already exists.' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const collegeAdmin = new CollegeAdmin({
      organizationName,
      organizationCode,
      organizationMail,
      websiteHandlerName,
      websiteHandlerMail,
      websiteHandlerPhoneNumber,
      password: hashedPassword
    });

    await collegeAdmin.save();

    try {
      await sendEmail({
        email: organizationMail,
        rollNo: organizationCode,
        password: password,
        isOtpEmail: false
      });
    } catch (emailError) {
      console.error('Error sending credentials email:', emailError);
    }

    res.status(201).json({ message: 'College Admin registered successfully.' });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ message: 'Server error.', error });
  }
});

// Login Route
router.post('/login', async (req, res) => {
  const { organizationCode, organizationMail, password } = req.body;

  try {
    const admin = await CollegeAdmin.findOne({ organizationCode, organizationMail });
    if (!admin) {
      return res.status(401).json({ message: 'Invalid organization code or email.' });
    }

    const isPasswordValid = await bcrypt.compare(password, admin.password);
    if (!isPasswordValid) {
      return res.status(401).json({ message: 'Invalid password.' });
    }

    const token = jwt.sign(
      { 
        id: admin._id, 
        organizationCode: admin.organizationCode,
        organizationName: admin.organizationName 
      },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.status(200).json({
      message: 'Login successful',
      token,
      admin: {
        organizationName: admin.organizationName,
        organizationCode: admin.organizationCode,
        organizationMail: admin.organizationMail
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ message: 'Server error.', error });
  }
});

// Get Profile Route
router.get('/profile', verifyToken, async (req, res) => {
  try {
    const { organizationCode } = req.user;
    
    const adminProfile = await CollegeAdmin.findOne(
      { organizationCode },
      { password: 0, __v: 0 }
    );

    if (!adminProfile) {
      return res.status(404).json({ message: 'Profile not found' });
    }

    res.status(200).json({
      success: true,
      profile: adminProfile
    });

  } catch (error) {
    console.error('Error fetching profile:', error);
    res.status(500).json({ message: 'Server error while fetching profile', error });
  }
});

// Edit Profile Route
router.put('/edit-profile', verifyToken, async (req, res) => {
  try {
    const { organizationCode } = req.user;
    const updates = req.body;

    const restrictedFields = ['password', 'organizationCode', '_id'];
    restrictedFields.forEach(field => delete updates[field]);

    const updatedProfile = await CollegeAdmin.findOneAndUpdate(
      { organizationCode },
      { $set: updates },
      { new: true, runValidators: true, select: '-password -__v' }
    );

    if (!updatedProfile) {
      return res.status(404).json({ message: 'Profile not found' });
    }

    res.status(200).json({
      success: true,
      message: 'Profile updated successfully',
      profile: updatedProfile
    });

  } catch (error) {
    console.error('Error updating profile:', error);
    res.status(500).json({ message: 'Server error while updating profile', error: error.message });
  }
});

// Upload Profile Picture Route
router.post('/upload-profile-picture', verifyToken, upload.single('profilePicture'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: 'No file uploaded.' });
    }

    const { organizationCode } = req.user;
    
    const admin = await CollegeAdmin.findOne({ organizationCode });
    
    if (!admin) {
      fs.unlinkSync(req.file.path);
      return res.status(404).json({ message: 'Admin profile not found.' });
    }

    if (admin.profilePicture) {
      const oldPicturePath = path.join('uploads/collegeadmin-profile-pictures', admin.profilePicture);
      if (fs.existsSync(oldPicturePath)) {
        fs.unlinkSync(oldPicturePath);
      }
    }

    admin.profilePicture = req.file.filename;
await admin.save();
res.status(200).json({
  success: true,
  message: 'Profile picture uploaded successfully',
  profilePicture: req.file.filename // Ensure this is sent back
});


  } catch (error) {
    if (req.file) {
      fs.unlinkSync(req.file.path);
    }
    console.error('Error uploading profile picture:', error);
    res.status(500).json({ message: 'Server error while uploading profile picture', error: error.message });
  }
});

// Verify OTP Route
router.post('/verify-otp', (req, res) => {
  const { otp } = req.body;

  if (!currentOtp) {
    return res.status(401).json({ message: 'OTP has expired.' });
  }

  if (otp.toString() === currentOtp.toString()) {
    currentOtp = null;
    clearTimeout(otpTimeout);
    return res.status(200).json({ message: 'OTP verified successfully!' });
  }

  return res.status(401).json({ message: 'Invalid OTP.' });
});

module.exports = router;