const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const Student = require('../../schema/student');


// GET route to fetch dashboard data
router.get('/college-dashboard/:organizationCode', async (req, res) => {
    try {
        const { organizationCode } = req.params;

        // Connect to the organization-specific collection
        const BranchModel = mongoose.model('Student', Student.schema, organizationCode);

        // Fetch all students
        const students = await BranchModel.find();

        // Calculate total students
        const studentCount = students.length;

        // Get projects, tasks, and quizzes count from only the first student (if exists)
        const referenceStudent = students[0] || { projects: [], tasks: [], quizzes: [] };

        const totalProjects = referenceStudent.projects?.length || 0;
        const totalTasks = referenceStudent.tasks?.length || 0;
        const totalQuizzes = referenceStudent.quizzes?.length || 0;

        res.status(200).json({
            studentCount,
            totalProjects,
            totalTasks,
            totalQuizzes
        });
    } catch (error) {
        console.error("Error fetching dashboard data:", error);
        res.status(500).json({ message: "Internal Server Error" });
    }
});

module.exports = router;
