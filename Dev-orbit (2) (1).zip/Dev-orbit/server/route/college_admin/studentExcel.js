const express = require('express');
const multer = require('multer');
const xlsx = require('xlsx');
const path = require('path');
const fs = require('fs');
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const { sendEmail } = require('../../sendEmail');
const router = express.Router();
const Student = require('../../schema/student');
require('dotenv').config();
const bcrypt = require('bcrypt');




// Authentication middleware - remains the same but now we'll use it more consistently
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];


  if (!token) return res.status(401).json({ error: 'Access denied. No token provided.' });


  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded; // Attach user info to request
    next();
  } catch (error) {
    return res.status(401).json({ error: 'Invalid token.' });
  }
};


// Storage configuration remains the same
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    const filename = file.originalname.split('.')[0];
    cb(null, filename + '-' + Date.now() + path.extname(file.originalname));
  }
});


const upload = multer({
  storage: storage,
  fileFilter: (req, file, cb) => {
    if (file.mimetype.includes('excel') || file.mimetype.includes('spreadsheetml')) {
      cb(null, true);
    } else {
      cb('Please upload only an Excel file.', false);
    }
  }
}).any();


const possibleClassFields = ['class', 'branch', 'year', 'batch', 'section'];


// Modified routes to use organization code from JWT token


router.post('/upload', authenticateToken, (req, res) => {
  upload(req, res, async function (err) {
      if (err) {
          return res.status(500).json({ error: `Upload error: ${err.message}` });
      }


      const organizationCode = req.user.organizationCode; // Extract organizationCode from token
      const file = req.files[0]; // Get the uploaded file


      try {
          // Read and parse the uploaded Excel file
          const workbook = xlsx.readFile(file.path);
          const sheet = workbook.Sheets[workbook.SheetNames[0]];
          const data = xlsx.utils.sheet_to_json(sheet);


          // Process student data
          for (let student of data) {
              // Generate a random password for each student
              const rawPassword = Math.random().toString(36).slice(-8);
              const hashedPassword = await bcrypt.hash(rawPassword, 10);
              student.password = hashedPassword; // Assign hashed password


              // Ensure organizationCode is included in each student object
              student.organizationCode = organizationCode;


              // Save the student object to the database
              const BranchModel = mongoose.model(organizationCode, Student.schema, organizationCode);
              await BranchModel.create(student);


              // Send email with the raw password (for their first login)
              try {
                  await sendEmail({
                      email: student.mail,
                      rollNo: student.rollNo,
                      password: rawPassword,
                      isOtpEmail: false,
                      organizationCode: organizationCode
                  });
              } catch (emailError) {
                  console.error(`Error sending email to ${student.mail}:`, emailError);
              }
          }


          res.status(200).json({ message: 'Data imported successfully with passwords.' });
      } catch (error) {
          console.error('Error processing Excel file:', error);
          res.status(500).json({ error: 'Error processing Excel file' });
      } finally {
          // Clean up uploaded file
          fs.unlink(file.path, (err) => {
              if (err) console.error('Error deleting file:', err);
          });
      }
  });
});
router.get('/classes', authenticateToken, async (req, res) => {
  try {
    console.log('Received organizationCode:', req.user.organizationCode);
    const ClassModel = mongoose.model(req.user.organizationCode, Student.schema, req.user.organizationCode);
    const classes = await ClassModel.distinct('class');
    console.log('Found classes:', classes);
    res.status(200).json(classes);
  } catch (error) {
    console.error('Detailed Error fetching classes:', error);
    res.status(500).json({ error: error.message, stack: error.stack });
  }
});
router.get('/:className/teams', authenticateToken, async (req, res) => {
  try {
    const { className } = req.params;
    const organizationCode = req.user.organizationCode;
    const ClassModel = mongoose.model(organizationCode, Student.schema, organizationCode);
    const teams = await ClassModel.distinct('team', { class: className });
    res.status(200).json(teams);
  } catch (error) {
    console.error('Error fetching teams:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});


router.get('/team/:className/:teamName', authenticateToken, async (req, res) => {
  try {
    const { className, teamName } = req.params;
    const organizationCode = req.user.organizationCode;
    const ClassModel = mongoose.model(organizationCode, Student.schema, organizationCode);
    const teamNumber = parseInt(teamName);
    const students = await ClassModel.find({ team: teamNumber, class: className });
    res.status(200).json(students);
  } catch (error) {
    console.error('Error fetching team data:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});




// Send-mails route with authentication
router.post('/send-mails', authenticateToken, async (req, res) => {
  const organizationCode = req.user.organizationCode; // Get from token


  try {
    const BranchModel = mongoose.model(organizationCode, Student.schema, organizationCode);
    const students = await BranchModel.find();


    if (!students || students.length === 0) {
      return res.status(404).json({ message: 'No student records found.' });
    }


    for (const student of students) {
      const { mail, rollNo } = student;
      if (!mail || !rollNo) continue;


      const password = Math.random().toString(36).slice(-8);
      await BranchModel.updateOne(
        { _id: student._id },
        { $set: { password } }
      );


      try {
        await sendEmail({
          email: mail,
          rollNo: rollNo,
          password: password,
          isOtpEmail: false
        });
      } catch (emailError) {
        console.error(`Error sending email to ${mail}:`, emailError);
      }
    }


    return res.status(200).json({ message: 'Credentials sent to all students.' });
  } catch (error) {
    console.error('Error sending emails:', error);
    return res.status(500).json({ message: 'Error sending emails.' });
  }
});
// Get-students route with authentication
router.get('/get-students', authenticateToken, async (req, res) => {
  const organizationCode = req.user.organizationCode; // Get from token


  try {
    const StudentModel = mongoose.models[organizationCode] ||
      mongoose.model(organizationCode, new mongoose.Schema({}, { strict: false }), organizationCode);


    const students = await StudentModel.find();


    if (!students || students.length === 0) {
      return res.status(404).json({ message: 'No students found.' });
    }


    return res.status(200).json({ students });
  } catch (error) {
    console.error('Error fetching students:', error);
    return res.status(500).json({ error: 'Error fetching student details.' });
  }
});


router.post('/student-login', async (req, res) => {
  const { mail, password, organizationCode } = req.body;
 
  if (!mail || !password || !organizationCode) {
      return res.status(400).json({ error: 'All fields are required.' });
  }


  try {
      const StudentModel = mongoose.model(organizationCode, Student.schema, organizationCode);
      const student = await StudentModel.findOne({ mail });
      console.log(student.password);


      if (!student) return res.status(404).json({ error: 'Student not found.' });


      // Compare the provided password with the stored hashed password
      const isMatch = await bcrypt.compare(password, student.password);
      if (!isMatch) {
        return res.status(401).json({ error: 'Invalid password.' });
      }


      // Generate JWT token including organizationCode
      // In your login route (student-login)
const token = jwt.sign(
  {
      id: student._id,
      organizationCode: organizationCode,
      name: student.name,
      rollNo: student.rollNo,
      class: student.class,
      mail: student.mail,
      githubId: student.githubId,
      team: student.team
  },
  process.env.JWT_SECRET,
  { expiresIn: '1h' }
);


      return res.status(200).json({
          message: 'Login successful',
          token,
          student: {
              name: student.name,
              rollNo: student.rollNo,
              class: student.class,
              mail: student.mail,
              githubId: student.githubId,
              team: student.team,
          },
      });
  } catch (error) {
      console.error('Error logging in:', error);
      return res.status(500).json({ error: 'An error occurred during login.' });
  }
});


// Student Login Route
router.post('/student-login', async (req, res) => {
  const { mail, password, organizationCode } = req.body;

  if (!mail || !password || !organizationCode) {
    return res.status(400).json({ error: 'All fields are required.' });
  }

  try {
    // Prevent OverwriteModelError by checking if the model already exists
    const StudentModel = mongoose.models[organizationCode] || mongoose.model(organizationCode, Student.schema, organizationCode);

    const student = await StudentModel.findOne({ mail });

    if (!student) {
      return res.status(404).json({ error: 'Student not found.' });
    }

    // Ensure password exists before comparing
    if (!student.password) {
      return res.status(401).json({ error: 'Invalid password.' });
    }

    // Compare the provided password with the stored hashed password
    const isMatch = await bcrypt.compare(password, student.password);
    if (!isMatch) {
      return res.status(401).json({ error: 'Invalid password.' });
    }

    // Generate JWT token including organizationCode
    const token = jwt.sign(
      {
        id: student._id,
        organizationCode: organizationCode,
        name: student.name,
        rollNo: student.rollNo,
        class: student.class,
        mail: student.mail,
        githubId: student.githubId,
        team: student.team,
      },
      process.env.JWT_SECRET,
      { expiresIn: '1h' }
    );

    res.json({ token, message: 'Login successful' });

  } catch (error) {
    console.error('Error logging in:', error);
    res.status(500).json({ error: 'Internal server error.' });
  }
});

// Get Student Profile Route
router.get('/profile/:organizationCode', authenticateToken, async (req, res) => {
  const { organizationCode } = req.params;
  const { rollNo, mail } = req.query; // Use body instead of query for sensitive data

  // Check if all required fields are present
  if (!organizationCode || !rollNo || !mail) {
    return res.status(400).json({ error: 'Missing required fields.' });
  }

  try {
    // Get the model dynamically based on the organizationCode
    const StudentModel = mongoose.model(organizationCode, Student.schema, organizationCode);
    const student = await StudentModel.findOne({ rollNo, mail });

    if (!student) {
      return res.status(404).json({ error: 'Student not found.' });
    }
    console.log('Student found:', student);
    // Return the student profile data
    return res.status(200).json(student);
  } catch (error) {
    console.error('Error fetching profile:', error);
    return res.status(500).json({ error: 'Internal Server Error' });
  }
});

router.post('/manual-add-student', authenticateToken, async (req, res) => {
  try {
    const { organizationCode } = req.user;
    const studentData = req.body;


    // Generate random password
    const rawPassword = Math.random().toString(36).slice(-8);
    const hashedPassword = await bcrypt.hash(rawPassword, 10);
    studentData.password = hashedPassword;
    studentData.organizationCode = organizationCode;


    const StudentModel = mongoose.model(organizationCode, Student.schema, organizationCode);
   
    // Check if student already exists
    const existingStudent = await StudentModel.findOne({
      $or: [{ rollNo: studentData.rollNo }, { mail: studentData.mail }]
    });


    if (existingStudent) {
      return res.status(400).json({ error: 'Student with this Roll No or Email already exists' });
    }


    const newStudent = new StudentModel(studentData);
    await newStudent.save();


    // Send email
    await sendEmail({
      email: studentData.mail,
      rollNo: studentData.rollNo,
      password: rawPassword,
      isOtpEmail: false,
      organizationCode
    });


    res.status(201).json({ message: 'Student added successfully' });
  } catch (error) {
    console.error('Error adding student:', error);
    res.status(500).json({ error: 'Failed to add student' });
  }
});
router.post('/manual-add-class', authenticateToken, async (req, res) => {
  try {
    const { organizationCode } = req.user;
    const { className } = req.body;


    if (!className) {
      return res.status(400).json({ error: 'Class name is required' });
    }


    const StudentModel = mongoose.model(organizationCode, Student.schema, organizationCode);
   
    // Check if class already exists
    const existingClasses = await StudentModel.distinct('class');
    if (existingClasses.includes(className)) {
      return res.status(400).json({ error: 'Class already exists' });
    }


    // Create placeholder student with modified rollNo
    const placeholderStudent = new StudentModel({
      name: 'Class Placeholder',
      rollNo: 0, // Use 0 instead of a string
      class: className,
      mail: `${className}@placeholder.com`,
      organizationCode,
      team: 0,
      githubId: `placeholder-${className}`
    });


    await placeholderStudent.save();


    res.status(201).json({
      message: 'Class added successfully',
      classes: await StudentModel.distinct('class')
    });
  } catch (error) {
    console.error('Error adding class:', error);
    res.status(500).json({ error: 'Failed to add class', details: error.message });
  }
});

router.get('/student-dashboard', authenticateToken, async (req, res) => {
  try {
    const { organizationCode, studentId } = req.query; // Access query parameters

    

    if (!organizationCode || !studentId) {
      return res.status(400).json({ message: 'Invalid request: organizationCode and studentId are required' });
    }

    const BranchModel = mongoose.model(
                'Student',
                Student.schema,
                organizationCode
            );
    const studentData = await BranchModel.findById(studentId);

    if (!studentData) {
      return res.status(404).json({ message: 'Student not found' });
    }

    res.json(studentData);
  } catch (error) {
    console.error('Error fetching student data:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});




module.exports = router;



