const express = require('express');
const multer = require('multer');
const path = require('path');
const Admin = require('../../schema/main_admin/login');
const CollegeAdmin = require('../../schema/college_admin/login');
const { sendEmail, generateOTP } = require('../../sendEmail');
const bcrypt = require('bcrypt');
require('dotenv').config();
const fs = require('fs');
const router = express.Router();
// Configure Multer storage for profile picture uploads


const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = 'uploads/mainadmin-profile-pictures';
    // Check if the directory exists
    if (!fs.existsSync(dir)) {
      // Create the directory if it doesn't exist
      fs.mkdirSync(dir, { recursive: true });
    }
    cb(null, dir); // Set the destination
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`);
  },
});

const upload = multer({ storage });


let currentOtp;
const OTP_EXPIRATION_TIME = 5 * 60 * 1000; // OTP expires after 5 minutes
let otpTimeout;
// Middleware to verify JWT token
const jwt = require('jsonwebtoken');
const JWT_SECRET = process.env.JWT_SECRET;

// Verify JWT middleware
const verifyToken = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) {
    return res.status(401).json({ message: 'Access denied. No token provided.' });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    console.log('Token verified successfully:', decoded);
    next();
  } catch (error) {
    return res.status(401).json({ message: 'Invalid token.' });
  }
};

// Admin login route
router.post('/login', async (req, res) => {
  const { mail, password } = req.body;

  if (!mail || !password) {
    return res.status(400).json({ message: 'Email and password are required.' });
  }

  try {
    const admin = await Admin.findOne({ mail });
    if (!admin) {
      return res.status(401).json({ message: 'Invalid credentials.' });
    }

    const isPasswordValid = await bcrypt.compare(password, admin.password);
    if (!isPasswordValid) {
      return res.status(401).json({ message: 'Invalid credentials.' });
    }

    currentOtp = generateOTP();
    if (otpTimeout) clearTimeout(otpTimeout);
    otpTimeout = setTimeout(() => {
      currentOtp = null;
    }, OTP_EXPIRATION_TIME);

    await sendEmail({
      email: mail,
      otp: currentOtp,
      isOtpEmail: true,
    });

    return res.status(200).json({ message: 'OTP sent to your email.' });
  } catch (error) {
    console.error('Login error:', error);
    return res.status(500).json({ message: 'Internal server error.' });
  }
});

// Verify OTP route
router.post('/verify-otp', (req, res) => {
  const { otp, mail } = req.body;

  if (!otp) {
    return res.status(400).json({ message: 'OTP is required.' });
  }

  if (otp.toString() === currentOtp?.toString()) {
    currentOtp = null;
    clearTimeout(otpTimeout);

    // Generate JWT token
    const token = jwt.sign({ email: mail }, JWT_SECRET, { expiresIn: '1h' });

    return res.status(200).json({ message: 'OTP verified successfully!', token });
  }

  return res.status(401).json({ message: 'Invalid OTP.' });
});
// college-login
router.post('/college-login', async (req, res) => {
  console.log("hello")
  const { organizationCode, organizationId} = req.body;
  try {
    const admin = await CollegeAdmin.findOne({ organizationCode});
    if (!admin) {
      return res.status(401).json({ message: 'Invalid organization code or Id.' });
    }

    const token = jwt.sign(
      { 
        id: admin._id, 
        organizationCode: admin.organizationCode,
        organizationName: admin.organizationName 
      },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );
    

    res.status(200).json({
      message: 'Login successful',
      token,
      admin: {
        organizationName: admin.organizationName,
        organizationCode: admin.organizationCode,
        organizationMail: admin.organizationMail
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ message: 'Server error.', error });
  }
});

// Add admin route
router.post('/add-admin', async (req, res) => {
  const { name, mail, password, phoneNumber } = req.body;

  try {
    const existingAdmin = await Admin.findOne({ mail });
    if (existingAdmin) {
      return res.status(400).json({ message: 'Admin with this email already exists.' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const newAdmin = new Admin({
      name,
      mail,
      password: hashedPassword,
      phoneNumber,
    });

    await newAdmin.save();

    await sendEmail({
      email: mail,
      rollNo: newAdmin._id,
      password,
      isOtpEmail: false,
    });

    res.status(201).json({ message: 'Admin added successfully.' });
  } catch (error) {
    console.error('Error adding admin:', error);
    res.status(500).json({ message: 'Internal server error.' });
  }
});
// Upload profile picture route
router.post('/upload-profile-picture', upload.single('profilePicture'), async (req, res) => {
  const { email } = req.body;

  try {
    if (!req.file) {
      return res.status(400).json({ message: 'No file uploaded.' });
    }

    const admin = await Admin.findOneAndUpdate(
      { mail: email },
      { profilePicture: req.file.path }, // Make sure this line saves the correct path
      { new: true }
    );

    if (!admin) {
      return res.status(404).json({ message: 'Admin not found.' });
    }

    res.status(200).json({
      message: 'Profile picture uploaded successfully.',
      profilePicture: admin.profilePicture,
    });
  } catch (error) {
    console.error('Error uploading profile picture:', error);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

// Get admin profile route
router.get('/profile/:email', async (req, res) => {
  const { email } = req.params;

  try {
    const admin = await Admin.findOne({ mail: email }).select('-password');

    if (!admin) {
      return res.status(404).json({ message: 'Admin not found.' });
    }

    res.status(200).json({
      name: admin.name,
      mail: admin.mail,
      phoneNumber: admin.phoneNumber,
      registeredDate: admin.registeredDate,
      profilePicture: admin.profilePicture,
    });
  } catch (error) {
    console.error('Error fetching admin details:', error);
    res.status(500).json({ message: 'Internal server error.' });
  }
});


router.get('/organizations',verifyToken ,  async (req, res) => {
  try {

    // Fetch organizations excluding sensitive fields
    const organizations = await CollegeAdmin.find({}, { password: 0, __v: 0 });

    // Check if any organizations exist
    if (organizations.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'No organizations found.'
      });
    }

    console.log(organizations);

    res.status(200).json({
      success: true,
      organizations
    });

  } catch (error) {
    console.error('Error fetching organizations:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Internal server error.' 
    });
  }
});

// Get single organization by ID or organization code
router.get('/organizations/:identifier', verifyToken, async (req, res) => {
  try {
    const { identifier } = req.params;
    
    const organization = await CollegeAdmin.findOne({
      $or: [
        { _id: identifier },
        { organizationCode: identifier }
      ]
    }, { password: 0, __v: 0 });

    if (!organization) {
      return res.status(404).json({ message: 'Organization not found.' });
    }

    res.status(200).json({
      success: true,
      organization
    });
  } catch (error) {
    console.error('Error fetching organization:', error);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

// Update organization
router.put('/organizations/:identifier', verifyToken, async (req, res) => {
  try {
    const { identifier } = req.params;
    const updates = req.body;

    // Remove sensitive fields from updates
    const restrictedFields = ['password', '_id', '__v'];
    restrictedFields.forEach(field => delete updates[field]);

    const organization = await CollegeAdmin.findOneAndUpdate(
      {
        $or: [
          { _id: identifier },
          { organizationCode: identifier }
        ]
      },
      { $set: updates },
      { new: true, runValidators: true, select: '-password -__v' }
    );

    if (!organization) {
      return res.status(404).json({ message: 'Organization not found.' });
    }

    res.status(200).json({
      success: true,
      message: 'Organization updated successfully',
      organization
    });
  } catch (error) {
    console.error('Error updating organization:', error);
    if (error.code === 11000) {
      return res.status(400).json({ message: 'Organization code or email already exists.' });
    }
    res.status(500).json({ message: 'Internal server error.' });
  }
});

// Delete organization
router.delete('/organizations/:identifier', verifyToken, async (req, res) => {
  try {
    const { identifier } = req.params;

    const organization = await CollegeAdmin.findOneAndDelete({
      $or: [
        { _id: identifier },
        { organizationCode: identifier }
      ]
    });

    if (!organization) {
      return res.status(404).json({ message: 'Organization not found.' });
    }

    // Delete profile picture if exists
    if (organization.profilePicture) {
      const picturePath = path.join('uploads/collegeadmin-profile-pictures', organization.profilePicture);
      if (fs.existsSync(picturePath)) {
        fs.unlinkSync(picturePath);
      }
    }

    res.status(200).json({
      success: true,
      message: 'Organization deleted successfully'
    });
  } catch (error) {
    console.error('Error deleting organization:', error);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

// Search organizations
router.get('/organizations/search/:query', verifyToken, async (req, res) => {
  try {
    const { query } = req.params;
    
    const organizations = await CollegeAdmin.find({
      $or: [
        { organizationName: { $regex: query, $options: 'i' } },
        { organizationCode: { $regex: query, $options: 'i' } },
        { organizationMail: { $regex: query, $options: 'i' } }
      ]
    }, { password: 0, __v: 0 });

    res.status(200).json({
      success: true,
      organizations
    });
  } catch (error) {
    console.error('Error searching organizations:', error);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

module.exports = router;
