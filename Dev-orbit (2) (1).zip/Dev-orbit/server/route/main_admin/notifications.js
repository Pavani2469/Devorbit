const express = require('express');
const router = express.Router();
const Notification = require('../../schema/notifications');
const CollegeAdmin = require('../../schema/college_admin/login');
const jwt = require('jsonwebtoken');
const JWT_SECRET = process.env.JWT_SECRET;

// Middleware to verify JWT token
const verifyToken = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) {
    return res.status(401).json({ message: 'Access denied. No token provided.' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    return res.status(401).json({ message: 'Invalid token.' });
  }
};

// Get all organization codes for dropdown
router.get('/get-organization-codes', verifyToken, async (req, res) => {
  try {
    const colleges = await CollegeAdmin.find({}, 'organizationCode organizationName')
      .sort({ organizationName: 1 }); // Sort by organization name
    
    if (!colleges.length) {
      return res.status(404).json({ 
        success: false, 
        message: 'No organizations found' 
      });
    }

    res.status(200).json({
      success: true,
      colleges: colleges.map(college => ({
        code: college.organizationCode,
        name: college.organizationName
      }))
    });
  } catch (error) {
    console.error('Error fetching organization codes:', error);
    res.status(500).json({ 
      success: false,
      message: 'Error fetching organization codes'
    });
  }
});

// Send notification
// Send notification
router.post('/send-notification', verifyToken, async (req, res) => {
  const { organizationCode, title, message } = req.body;

  if (!organizationCode || !title || !message) {
    return res.status(400).json({ success: false, message: 'All fields are required' });
  }

  try {
    // Verify if organization exists
    const organizationExists = await CollegeAdmin.findOne({ organizationCode });
    if (!organizationExists) return res.status(404).json({ success: false, message: 'Organization not found' });

    const newNotification = new Notification({
      organizationCode,
      title,
      message,
      createdAt: new Date()
    });

    await newNotification.save();
    
    res.status(201).json({ success: true, message: 'Notification sent successfully', notification: newNotification });
  } catch (error) {
    console.error('Error sending notification:', error);
    res.status(500).json({ success: false, message: 'Error sending notification' });
  }
});

// Get notifications for an organization
router.get('/:organizationCode', verifyToken, async (req, res) => {
  const { organizationCode } = req.params;

  try {
    const notifications = await Notification.find({ organizationCode }).sort({ createdAt: -1 });
    
    res.status(200).json({
      success: true,
      notifications
    });
  } catch (error) {
    console.error('Error fetching notifications:', error);
    res.status(500).json({ success: false, message: 'Error fetching notifications' });
  }
});

module.exports = router;