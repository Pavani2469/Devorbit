const express = require('express');
const axios = require('axios');
const multer = require('multer');
const Student = require('../schema/college_admin/studentExcel');
const mongoose = require('mongoose');

const router = express.Router();

// Set up multer to store files in memory
const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

// Function to upload files to GitHub
const uploadToGitHub = async (req, res) => {
    const { folderName, githubToken, repoOwner, repoName, studentId, category, organizationCode, itemId } = req.body;
    const files = req.files; // Access uploaded files

    // Validation
    if (!githubToken || !repoOwner || !repoName) {
        return res.status(400).json({ message: 'GitHub Token, Repository Owner, and Repository Name are required' });
    }

    if (!folderName || !files || files.length === 0) {
        return res.status(400).json({ message: 'Folder name and files are required' });
    }

    try {
        const results = [];

        // Upload files to GitHub
        for (const file of files) {
            const filePathInRepo = `${folderName}/${file.originalname}`; // Dynamic file path
            const fileContent = file.buffer.toString('base64'); // Convert file to Base64

            let sha;
            try {
                // Check if the file already exists in the GitHub repository
                const fileResponse = await axios.get(
                    `https://api.github.com/repos/${repoOwner}/${repoName}/contents/${filePathInRepo}`,
                    {
                        headers: {
                            Authorization: `Bearer ${githubToken}`,
                        },
                    }
                );
                sha = fileResponse.data.sha; // Get the file's SHA if it exists
            } catch (error) {
                if (error.response && error.response.status !== 404) {
                    throw error; // Handle non-404 errors
                }
            }

            // Upload or update the file in the GitHub repository
            const response = await axios.put(
                `https://api.github.com/repos/${repoOwner}/${repoName}/contents/${filePathInRepo}`,
                {
                    message: `Upload ${file.originalname}`,
                    content: fileContent,
                    branch: 'main',
                    sha: sha || undefined,
                },
                {
                    headers: {
                        Authorization: `Bearer ${githubToken}`,
                        'Content-Type': 'application/json',
                    },
                }
            );

            results.push(response.data.content.html_url); // Collect URLs of uploaded files
        }

        // After successful upload, update the database
        const BranchModel = mongoose.model(
            'Student',
            Student.schema,
            organizationCode
        );

        const updateResult = await BranchModel.updateOne(
            { _id: studentId, [`${category}.itemId`]: itemId },
            {
                $set: {
                    [`${category}.$.status`]: true,
                    [`${category}.$.fileUrls`]: results // Store uploaded file URLs
                }
            }
        );

        if (updateResult.modifiedCount === 0) {
            return res.status(400).json({ message: 'No students updated or task not found.' });
        }

        // Send the final response
        res.status(200).json({
            message: 'Files uploaded successfully and status updated',
            urls: results,
        });
    } catch (error) {
        if (error.response) {
            console.error('GitHub API error:', error.response.data);
            res.status(error.response.status).json({
                message: 'Error uploading files',
                error: error.response.data.message,
            });
        } else {
            console.error('Unexpected error:', error.message);
            res.status(500).json({ message: 'Unexpected error occurred', error: error.message });
        }
    }
};

// Define the route for file upload
router.post('/upload', upload.array('files'), uploadToGitHub);

module.exports = router;
