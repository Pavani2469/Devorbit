const express = require('express');
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const Student = require('../../schema/student');
require('dotenv').config();

const router = express.Router();

// Student Login Route
router.post('/student-login', async (req, res) => {
  const { mail, password, organizationCode } = req.body;

  if (!mail || !password || !organizationCode) {
    return res.status(400).json({ error: 'All fields are required.' });
  }

  try {
    // Access the correct organization collection
    const StudentModel = mongoose.model(organizationCode, Student.schema, organizationCode);
    const student = await StudentModel.findOne({ mail });

    if (!student) {
      return res.status(404).json({ error: 'Student not found.' });
    }

    // Compare provided password with the stored hashed password
    const isMatch = await bcrypt.compare(password, student.password);
    if (!isMatch) {
      return res.status(401).json({ error: 'Invalid password.' });
    }

    // Generate a JWT token
    const token = jwt.sign(
      { id: student._id, organizationCode },
      process.env.JWT_SECRET,
      { expiresIn: '1h' }
    );

    res.status(200).json({
      message: 'Login successful',
      token,
      student: {
        name: student.name,
        rollNo: student.rollNo,
        class: student.class,
        mail: student.mail,
        githubId: student.githubId,
        team: student.team,
      }
    });
  } catch (error) {
    console.error('Error logging in:', error);
    res.status(500).json({ error: 'An error occurred during login.' });
  }
});

module.exports = router;
