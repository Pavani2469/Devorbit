import React, { useEffect, useState } from 'react';
import axios from 'axios';

const ProtectedData = () => {
  const [protectedData, setProtectedData] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchProtectedData = async () => {
      const token = localStorage.getItem('token'); // Retrieve the token from localStorage

      if (!token) {
        setError('No token found. Please log in.');
        return;
      }

      try {
        const response = await axios.get('http://localhost:5000/protected-data', {
          headers: { Authorization: `Bearer ${token}` }, // Pass the token in the Authorization header
        });

        setProtectedData(response.data);
      } catch (err) {
        const errorMessage = err.response?.data?.error || 'Failed to fetch protected data.';
        setError(errorMessage);
      }
    };

    fetchProtectedData();
  }, []);

  return (
    <div>
      <h1>Protected Data</h1>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      {protectedData ? (
        <div>
          <p>{protectedData.message}</p>
          <pre>{JSON.stringify(protectedData.user, null, 2)}</pre> {/* Display user data */}
        </div>
      ) : (
        !error && <p>Loading...</p>
      )}
    </div>
  );
};

export default ProtectedData;
