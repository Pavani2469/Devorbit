const express = require('express');
const nodemailer = require('nodemailer');
const ContactMessage = require('../schema/contact'); // Ensure the model is correctly imported
const router = express.Router();

// Email Transporter Configuration
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.CONTACT_MAIL,
    pass: process.env.CONTACT_PASSWORD,
  },
});

// POST Route to Handle Contact Form Submission
router.post('/send', async (req, res) => {
  const { name, email, message } = req.body;

  try {
    // Save the message to MongoDB
    const newMessage = new ContactMessage({ name, email, message });
    await newMessage.save();

    // Send an email notification
    await transporter.sendMail({
      from: process.env.CONTACT_MAIL,
      to: process.env.CONTACT_MAIL, // Admin email
      subject: `New Message from ${name}`,
      text: `You have received a new message:\n\nName: ${name}\nEmail: ${email}\nMessage: ${message}`,
    });

    res.status(201).json({ message: 'Message saved and email sent successfully!' });
  } catch (error) {
    console.error('Error saving message or sending email:', error.message);
    res.status(500).json({ error: 'Failed to process the message' });
  }
});

// GET Route to Fetch All Messages from the Last Month
router.get('/', async (req, res) => {
  try {
    const oneMonthAgo = new Date();
    oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1); // Get the date one month ago

    const messages = await ContactMessage.find({
      createdAt: { $gte: oneMonthAgo } // Fetch messages from the last month
    });

    res.status(200).json(messages);
  } catch (error) {
    console.error('Error fetching messages:', error.message);
    res.status(500).json({ error: 'Failed to fetch messages' });
  }
});


// DELETE Route to Delete Selected Messages
router.delete('/', async (req, res) => {
  const { ids } = req.body;

  try {
    await ContactMessage.deleteMany({ _id: { $in: ids } });
    res.status(200).json({ message: 'Messages deleted successfully' });
  } catch (error) {
    console.error('Error deleting messages:', error.message);
    res.status(500).json({ error: 'Failed to delete messages' });
  }
});

module.exports = router;
