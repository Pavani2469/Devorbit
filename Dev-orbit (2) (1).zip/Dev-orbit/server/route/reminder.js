const express = require('express');
const jwt = require('jsonwebtoken');
const mongoose = require('mongoose');
const router = express.Router();
require('dotenv').config();

// JWT verification middleware (same as in give-task.js)
const verifyToken = (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ message: 'No valid authorization header found' });
    }

    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    req.organizationCode = decoded.organizationCode;
    next();
  } catch (error) {
    console.error('Token verification error:', error);
    return res.status(401).json({ message: 'Invalid or expired token' });
  }
};

// Create a dynamic model function
const getDynamicReminderModel = (organizationCode) => {
  const collectionName = `${organizationCode}_reminders`;
  
  // Define the reminder schema
  const reminderSchema = new mongoose.Schema({
    date: { type: Date, required: true },
    description: { type: String, required: true },
    meetingLink: { type: String },
    organizationCode: { type: String, required: true }
  }, { timestamps: true });

  return mongoose.models[collectionName] || mongoose.model(collectionName, reminderSchema);
};

// Get all reminders for an organization
router.get('/get-reminder', verifyToken, async (req, res) => {
  try {
    const DynamicReminder = getDynamicReminderModel(req.organizationCode);
    const reminders = await DynamicReminder.find({ organizationCode: req.organizationCode });
    res.status(200).json(reminders);
  } catch (error) {
    console.error('Error fetching reminders:', error);
    res.status(500).json({ error: 'Error fetching reminders' });
  }
});

// Add or update a reminder
router.post('/add-reminder', verifyToken, async (req, res) => {
  const { date, description, meetingLink } = req.body;
  console.log('Request to Add Reminder:', req.body);

  try {
    const DynamicReminder = getDynamicReminderModel(req.organizationCode);
    
    const reminder = await DynamicReminder.findOneAndUpdate(
      { 
        date,
        organizationCode: req.organizationCode 
      },
      { 
        description, 
        meetingLink,
        organizationCode: req.organizationCode
      },
      { new: true, upsert: true }
    );
    
    res.status(200).json({ message: 'Reminder saved successfully', reminder });
  } catch (error) {
    console.error('Error saving reminder:', error);
    res.status(500).json({ error: 'Error saving reminder' });
  }
});

// Delete a reminder
router.delete('/delete-reminder/:date', verifyToken, async (req, res) => {
  const { date } = req.params;
  console.log(date);

  try {
    const DynamicReminder = getDynamicReminderModel(req.organizationCode);
    const parsedDate = new Date(date);
    
    await DynamicReminder.findOneAndDelete({ 
      date: parsedDate,
      organizationCode: req.organizationCode 
    });
    
    res.status(200).json({ message: 'Reminder deleted successfully' });
  } catch (error) {
    console.error('Error deleting reminder:', error);
    res.status(500).json({ error: 'Error deleting reminder' });
  }
});

module.exports = router;