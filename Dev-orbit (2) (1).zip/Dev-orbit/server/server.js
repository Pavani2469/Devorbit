const express = require('express');
const cors = require('cors');
const adminRoutes = require('./route/main_admin/login');
const contactRoutes = require('./route/contact');
const collegeAdminRoutes = require('./route/college_admin/login');
//const classRoutes = require('./route/college_admin/classes')
const { connectToDB } = require('./db');
const { logger, errorHandler } = require('./middleware');
const excelRoutes = require('./route/college_admin/studentExcel');
//const taskRoutes = require('./route/college_admin/give-task'); // New import for combined routes
const path = require('path');
const app = express();
const calendarRoutes = require('./route/reminder');
const taskRoutes = require('./route/college_admin/give-task'); 
const mainAdminNotificationsRouter = require('./route/main_admin/notifications');
const collegeAdminNotificationsRouter = require('./route/college_admin/notifications');
const githubroutes = require('./route/githubRoutes');
const collegeDashboard = require('./route/college_admin/CollegeDashboard');


app.use(cors({
  origin: 'http://localhost:3000',
  methods: ['GET', 'POST', 'PUT', 'DELETE']
}));

app.use(express.json());

// Connect to devorbit database at startup
connectToDB();

// Use middleware
app.use(logger);

// Serve uploaded files
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Routes
app.use('/', excelRoutes); 
app.use('/admin', adminRoutes); // Admin routes
app.use('/college-admin', collegeAdminRoutes); 
app.use('/college', collegeDashboard);
app.use('/tasks', taskRoutes); // New management routes for projects, quizzes, and tasks
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
// Error handling middleware
app.use('/contact', contactRoutes);
app.use('/reminder', calendarRoutes);
app.use('/admin/notifications', mainAdminNotificationsRouter);
app.use('/college-admin/notifications', collegeAdminNotificationsRouter);
app.use('/github', githubroutes);
app.use(errorHandler);

// Start Server  
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
}); 