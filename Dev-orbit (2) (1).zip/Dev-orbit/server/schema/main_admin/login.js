const mongoose = require('mongoose');

const adminSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    mail: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    phoneNumber: { type: String, required: true },
    profilePicture: { type: String, default: '' }, // Add this field
  },
  { collection: 'main_admins' } // Specify the collection name here
);

module.exports = mongoose.model('Admin', adminSchema);
