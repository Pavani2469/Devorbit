// backend/schema/college_admin/give-task.js
const mongoose = require('mongoose');

const itemSchema = new mongoose.Schema({
  type: { type: String, required: true },
  title: { type: String, required: true },
  startDate: { type: Date, required: true },
  endDate: { type: Date, required: true },
  startTime: String, // New field
  endTime: String,   // New field
  description: String,
  filePath: String,
  questions: [{
    question: String,
    options: [String],
    correctAnswer: String
  }],
  organizationCode: { type: String, required: true }
}, { timestamps: true });


exports.Item = mongoose.model('Item', itemSchema);