// models/CollegeAdmin.js
const mongoose = require('mongoose');

const collegeAdminSchema = new mongoose.Schema({
  organizationName: { type: String, required: true },
  organizationCode: { type: String, required: true, unique: true },
  organizationMail: { type: String, required: true, unique: true },
  websiteHandlerName: { type: String, required: true },
  websiteHandlerMail: { type: String, required: true },
  websiteHandlerPhoneNumber: { type: String, required: true },
  password: { type: String, required: true }
},
{ collection: 'college_admins' }
);

module.exports = mongoose.model('CollegeAdmin', collegeAdminSchema);
