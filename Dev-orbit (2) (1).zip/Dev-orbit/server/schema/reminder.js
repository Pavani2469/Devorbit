const mongoose = require('mongoose');

const reminderSchema = new mongoose.Schema({
  date: { type: String, required: true, unique: true },
  description: { type: String, required: true },
  meetingLink: { type: String },
});

module.exports = mongoose.model('Reminder', reminderSchema);
