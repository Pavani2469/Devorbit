const mongoose = require('mongoose');

const studentSchema = new mongoose.Schema({
    name: { type: String, required: true },
    rollNo: { type: String, required: true },
    class: { type: String, required: true },
    mail: { type: String, required: true },
    githubId: { type: String, required: false },
    team: { type: Number, required: true },
    role: {
        type: String,
        enum: ['Team Lead', 'Team Member'],
        default: 'Team Member'
    },
    password: { type: String, required: false },
    projects: { 
        type: [{ itemId: mongoose.Schema.Types.ObjectId, status: Boolean }], 
        default: [] 
    },
    tasks: { 
        type: [{ itemId: mongoose.Schema.Types.ObjectId, status: Boolean }], 
        default: []
    },
    quizzes: { 
        type: [{ itemId: mongoose.Schema.Types.ObjectId, status: Boolean }], 
        default: []
    },
    organizationCode: { type: String, required: true }
});

module.exports = mongoose.models.Student || mongoose.model('Student', studentSchema);
