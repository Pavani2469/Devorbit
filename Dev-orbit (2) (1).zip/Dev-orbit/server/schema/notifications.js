const mongoose = require('mongoose');

const notificationSchema = new mongoose.Schema({
  organizationCode: {
    type: String,
    required: true
  },
  title: {
    type: String,
    required: true
  },
  message: {
    type: String,
    required: true
  },
  status: {
    type: String,
    enum: ['unread', 'read'],
    default: 'unread'
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
}, { collection: 'notifications' });

module.exports = mongoose.model('Notification', notificationSchema);